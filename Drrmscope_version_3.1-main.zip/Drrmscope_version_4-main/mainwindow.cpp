#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QImage>
#include <QPixmap>
#include <QKeyEvent>
#include <QCoreApplication>
#include <QApplication>
#include <QFileInfo>
#include <QDir>
#include <QDateTime>
#include <QDebug>
#include <QProcessEnvironment>
#include <QTimer>
#include <QIcon>
#include <QSlider>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QFile>
#include <QByteArray>

#include <vector>

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdio> // For popen and pclose
#include <cstring> // For strstr and strchr

#include <opencv2/opencv.hpp>
#include <opencv2/objdetect.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <QMessageBox>
#include <QFileSystemWatcher>
#include <QPropertyAnimation>
#include <QElapsedTimer>
#include <linux/i2c-dev.h>
#include <errno.h>
#include <QThread>  // For QThread::msleep

#include <QWidget>
#include <QTouchEvent>
#include <QList>
#include <QBuffer>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>  // Include QJsonArray for handling JSON arrays
#include <opencv2/opencv.hpp>  // Include OpenCV headers as needed

#define MAX17043_VCELL          0x02
#define MAX17043_SOC            0x04
#define MAX17043_MODE           0x06
#define MAX17043_VERSION        0x08
#define MAX17043_CONFIG         0x0c
#define MAX17043_COMMAND        0xfe
#define I2C_DEVICE "/dev/i2c-2"  // Define I2C device path here

using namespace cv;
bool galleryToFront= false;
int currentIndex = 0;
double zoom=1.0;
bool gpioset=true;

const int GPIO_118 = 118;
const int GPIO_124 = 124;
const int GPIO_83 = 83;
const int GPIO_97 = 97;
const int GPIO_96 = 96;
const int GPIO_88 = 88;
const int GPIO_89 = 89;
const int GPIO_132 = 132;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , capture(new cv::VideoCapture())
    , checkTimer(new QTimer(this))
    , timer(new QTimer(this))
    , timer_prompt(new QTimer(this))
    , timer_prompt2(new QTimer(this))
    , timer_date(new QTimer(this))
    ,frameCount(0)
    ,currentFPS(0.0)
    , contrast(1.0)
    , brightness(20.0)
    ,settingsIconToggled(false)  // Initialize the variable
    ,gridToggled(false)
    ,brightnessIconToggled(false)
    ,contrastIconToggled(false)
    ,setgridIconToggled(false)
{
    ui->setupUi(this);

    inSleepMode = false; // Initialize to false for normal mode
    gpioset = false; // Initialize GPIOs not set initially
    ui->brightness_bar->setVisible(false); // Initially invisible
    ui->contrast_bar->setVisible(false); // Initially invisible
    ui->wifi_connected->hide();
    ui->top_prompt->lower();

    ui->zoombar->setVisible(false);
    setupSystem();
    setupGPIO();
    setupCamera();
    setupTimers();

    // Initialize the timer and start it
    fpsTimer = new QTimer(this);
    connect(fpsTimer, &QTimer::timeout, this, &MainWindow::updateFPS);
    fpsTimer->start(1000); // Update FPS every second

    // Start the elapsed timer
    elapsedTimer.start();

    connect(ui->contrast_bar, &QSlider::valueChanged, this, &MainWindow::updateContrast);
    connect(ui->brightness_bar, &QSlider::valueChanged, this, &MainWindow::updateBrightness);

    //for i2c
    openI2C();  // Open the I2C bus

    if (initializeMAX17043() == 0) {
        qDebug() << "MAX17043 initialized successfully.";
    } else {
        qWarning() << "Failed to initialize MAX17043.";
    }

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateBatteryInfo()));
    timer->start(2000); // Update battery info every 2000 milliseconds (2 seconds)


}

void MainWindow::updateFPS()
{
    int elapsed = elapsedTimer.elapsed();
    if (elapsed > 0) {
        currentFPS = (frameCount / (elapsed / 1000.0));
    } else {
        currentFPS = 0.0;
    }

    qDebug() << "FPS:" << currentFPS;

    // Reset the frame count and restart the timer
    frameCount = 0;
    elapsedTimer.restart();
}

void MainWindow::setupCamera()
{
    int status = system("modprobe ov5645_camera_mipi_v2");
    if (status != 0) {
        qDebug() << "Error: Failed to load camera module!";
        return;
    }
    qDebug() << "Camera module loaded successfully!";

    capture->open(0);
    if (!capture->isOpened()) {
        qDebug() << "Error: Camera not detected!";
        return;
    }
    qDebug() << "Camera Initialized!";
    capture->set(cv::CAP_PROP_FRAME_WIDTH, 640);
    capture->set(cv::CAP_PROP_FRAME_HEIGHT, 480);
    capture->set(cv::CAP_PROP_FPS, 30);


    //    double width = capture->get(cv::CAP_PROP_FRAME_WIDTH);
    //    double height = capture->get(cv::CAP_PROP_FRAME_HEIGHT);
    //    double fps = capture->get(cv::CAP_PROP_FPS);

    //    qDebug() << "Camera settings: Width:" << width << " Height:" << height << " FPS:" << fps;
}

void MainWindow::setupTimers()
{
    connect(checkTimer, &QTimer::timeout, this, &MainWindow::checkConnection);
    checkTimer->setInterval(20000);
    checkTimer->start();

    connect(timer, &QTimer::timeout, this, &MainWindow::updateFrame);
    timer->start(10);

    connect(timer_date, &QTimer::timeout, this, &MainWindow::datetime);
    timer_date->start(1000);

    timer_topbar = new QTimer(this);
    connect(timer_topbar, SIGNAL(timeout()), this, SLOT(display_topbar()));
}

void MainWindow::setupSystem()
{
    // Disable Bluetooth
    system("sudo systemctl disable bluetooth");
    system("sudo systemctl stop bluetooth");

    // Adding server in /etc/resolv.conf file
    QFile file("/etc/resolv.conf");
    if (file.open(QIODevice::Append | QIODevice::Text)) {
        QTextStream out(&file);
        out << "nameserver 8.8.8.8\n";
        out << "nameserver 8.8.4.4\n";
        file.close();
    } else {
        qDebug() << "Failed to open /etc/resolv.conf for writing";
    }

    // Write NTP server entries to /etc/ntp.conf
    updateNtpConf();
    setTimeZone();
    system("sudo systemctl enable ntpd.service");
    system("sudo systemctl restart ntpd.service");
    system("sudo systemctl restart ntpdate.service");
    system("sudo ntpdate 0.pk.pool.ntp.org");
    system("sudo systemctl disable ntpd.service");
    system("date");

}

void MainWindow::setupGPIO()
{
    const std::vector<int> gpios = {GPIO_118, GPIO_124, GPIO_83, GPIO_97, GPIO_96, GPIO_88, GPIO_89, GPIO_132};
    const std::vector<QString> directions = {"in", "out", "out", "in", "in", "in", "in", "in"};
    const std::vector<QString> edges = {"falling", "", "", "falling", "falling", "falling", "falling", "falling"};


    // Add path to file watcher for GPIO 89 value
    watcher_sleep.addPath("/sys/class/gpio/gpio89/value");
    connect(&watcher_sleep, &QFileSystemWatcher::fileChanged, this, &MainWindow::gpio89Changed);
    qDebug() << "Watcher set up for GPIO 89.";

    // Print out all added paths for verification
    QStringList paths = watcher_sleep.files();
    qDebug() << "Watcher paths:" << paths;

    for (size_t i = 0; i < gpios.size(); ++i) {
        system(("echo " + QString::number(gpios[i]) + " > /sys/class/gpio/export").toStdString().c_str());
        qDebug() << "GPIO" << gpios[i] << "exported";
        system(("echo \"" + directions[i] + "\" > /sys/class/gpio/gpio" + QString::number(gpios[i]) + "/direction").toStdString().c_str());
        qDebug() << "GPIO" << gpios[i] << "direction set";
        if (!edges[i].isEmpty()) {
            system(("echo " + edges[i] + " > /sys/class/gpio/gpio" + QString::number(gpios[i]) + "/edge").toStdString().c_str());
        }
    }
}

MainWindow::~MainWindow()
{
    delete ui;

}

void MainWindow::updateNtpConf() {
    QFile ntpConfFile("/etc/ntp.conf");
    if (!ntpConfFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open /etc/ntp.conf for reading";
        return;
    }

    QTextStream in(&ntpConfFile);
    QStringList ntpConfigLines;
    bool driftfileExist = false;
    bool loggingExist = false;
    bool defaultRestrictionsExist = false;
    QSet<QString> existingServers;

    // Read existing configurations
    while (!in.atEnd()) {
        QString line = in.readLine();
        QString trimmedLine = line.trimmed();
        if (trimmedLine.startsWith("server") && !trimmedLine.contains("127.127.1.0")) {
            existingServers.insert(trimmedLine);
        } else if (trimmedLine.startsWith("driftfile")) {
            driftfileExist = true;
        } else if (trimmedLine.startsWith("logfile")) {
            loggingExist = true;
        } else if (trimmedLine.startsWith("restrict")) {
            defaultRestrictionsExist = true;
        }
        ntpConfigLines << line;
    }
    ntpConfFile.close();

    // List of required server lines
    QStringList requiredServers = {
        "server 0.pk.pool.ntp.org iburst",
        "server 1.pk.pool.ntp.org iburst",
        "server 2.pk.pool.ntp.org iburst",
        "server 3.pk.pool.ntp.org iburst"
    };

    // Add missing server lines
    for (const QString &server : requiredServers) {
        if (!existingServers.contains(server)) {
            qDebug() << "Adding server:" << server;
            ntpConfigLines << server;
        }
    }

    // Add missing configurations
    if (!driftfileExist) {
        qDebug() << "Adding driftfile configuration";
        ntpConfigLines << "\n# Specify the drift file location";
        ntpConfigLines << "driftfile /var/lib/ntp/drift";
    }
    if (!loggingExist) {
        qDebug() << "Adding logging configuration";
        ntpConfigLines << "\n# Logging";
        ntpConfigLines << "logfile /var/log/ntp.log";
    }
    if (!defaultRestrictionsExist) {
        qDebug() << "Adding default restrictions";
        ntpConfigLines << "\n# Default restrictions";
        ntpConfigLines << "# Allow localhost to query the NTP server";
        ntpConfigLines << "restrict 127.0.0.1";
        ntpConfigLines << "restrict ::1";
    }

    // Write the updated configuration lines back to the file
    QFile ntpConfFileWrite("/etc/ntp.conf");
    if (!ntpConfFileWrite.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Failed to open /etc/ntp.conf for writing";
        return;
    }

    QTextStream out(&ntpConfFileWrite);
    for (const QString& line : ntpConfigLines) {
        out << line << "\n"; // Add newline character
    }
    ntpConfFileWrite.close();
    qDebug() << "NTP configuration file updated successfully";
}

void MainWindow::setTimeZone() {
    QProcess process;
    QStringList args;
    args << "-sf" << "/usr/share/zoneinfo/Asia/Karachi" << "/etc/localtime";
    process.start("ln", args);
    process.waitForFinished();
    if (process.exitCode() != 0) {
        qDebug() << "Failed to set timezone to Karachi";
    } else {
        qDebug() << "Timezone set to Karachi successfully";
    }
}

void MainWindow::updateFrame()
{
    // Check if capture object is valid
    if (!capture || !capture->isOpened()) {
        qDebug() << "Error: Camera not detected or capture object is invalid!";
        return;
    }

    // Capture frame
    *capture >> frame;
    if (frame.empty()) {
        qDebug() << "Error: Captured frame is empty!";
        return;
    }

    frame.convertTo(frame, -1, contrast, brightness);

    // Calculate zoom rectangle
    cv::Rect2f zoomRect((frame.size().width / 2) * (1 - 1 / zoom), (frame.size().height / 2) * (1 - 1 / zoom), frame.size().width / zoom, frame.size().height / zoom);
    cv::Mat zoomedImage = frame(zoomRect);

    // Calculate width and height factors
    double w_factor = static_cast<double>(480) / zoomedImage.size().width;
    double h_factor = static_cast<double>(640) / zoomedImage.size().height;

    // Resize the cropped region with higher-quality interpolation
    cv::Mat resized_frame;
    cv::resize(zoomedImage, resized_frame, cv::Size(), w_factor, h_factor, cv::INTER_LINEAR);

    // Rotate the resized frame
    cv::Mat rotatedFrame;
    cv::rotate(resized_frame, rotatedFrame, cv::ROTATE_90_CLOCKWISE);

    // Store the final processed frame
    processedFrame = rotatedFrame;

    // Convert the rotated frame to QImage
    QImage qimg((uchar*)rotatedFrame.data, rotatedFrame.cols, rotatedFrame.rows, QImage::Format_RGB888);
    QPixmap pixmap = QPixmap::fromImage(qimg.rgbSwapped());  // Convert BGR to RGB

    // Display the rotated frame
    ui->label->setPixmap(pixmap.scaled(ui->label->size(), Qt::KeepAspectRatio, Qt::FastTransformation));

    // Increment the frame count
    frameCount++;
}

void MainWindow::on_capture_clicked()
{
    QString currentDateTime = QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss");
    QString baseName = "DermScope";
    QString fileName = QString("%1_%2.jpg").arg(baseName).arg(currentDateTime);

    QString directoryPath = "/opt/Dermscope_v4/bin/results/";
    QDir directory(directoryPath);
    if (!directory.exists()) {
        if (!directory.mkpath(directoryPath)) {
            // Error: Failed to create directory
            qDebug() << "Error: Failed to create directory";
            return; // Return or handle the error accordingly
        }
    }

    // Save the processed frame using OpenCV
    if (!processedFrame.empty()) {
        // Construct the full path to save the image
        std::string imagePath = directoryPath.toStdString() + fileName.toStdString();

        // Save image using OpenCV
        if (!cv::imwrite(imagePath, processedFrame)) {
            qDebug() << "Failed to save image:" << QString::fromStdString(imagePath);
            return;
        }

        // UI animation and message display
        ui->top_prompt->raise();
        ui->top_prompt->show();
        QPropertyAnimation *animation = new QPropertyAnimation(ui->top_prompt, "geometry");
        animation->setDuration(100);
        QRect startRect = QRect(120, 0, ui->top_prompt->width(), ui->top_prompt->height());
        QRect endRect = QRect(120, 50, ui->top_prompt->width(), ui->top_prompt->height());
        animation->setStartValue(startRect);
        animation->setEndValue(endRect);

        QFont font("Product Sans", 24, QFont::Bold);
        ui->text->setFont(font);
        ui->text->setAlignment(Qt::AlignCenter);
        ui->text->setText("Image Saved Successfully");
        animation->start();
        timer_topbar->start(2000);

        // Now send the image to the server
        sendImageToServer(fileName, processedFrame);

    } else {
        // UI animation and error message display if image processing failed
        ui->top_prompt->raise();
        ui->top_prompt->show();
        QPropertyAnimation *animation = new QPropertyAnimation(ui->top_prompt, "geometry");
        animation->setDuration(100);
        QRect startRect = QRect(120, 0, ui->top_prompt->width(), ui->top_prompt->height());
        QRect endRect = QRect(120, 50, ui->top_prompt->width(), ui->top_prompt->height());
        animation->setStartValue(startRect);
        animation->setEndValue(endRect);

        ui->msgbox->setText("Error Capturing Image!");
        animation->start();
        timer_topbar->start(2000);
    }
}



void MainWindow::sendImageToServer(const QString &fileName, const cv::Mat &processedFrame)
{
    // Convert OpenCV Mat to QImage
    QImage qImage((uchar*)processedFrame.data, processedFrame.cols, processedFrame.rows, QImage::Format_BGR888); // Assuming image format is BGR

    // Convert QImage to QByteArray for server upload (if needed)
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    qImage.save(&buffer, "JPG");

    // Convert QByteArray to Base64
    QString imgData = byteArray.toBase64();

    // Prepare JSON data to send
    QJsonObject json;
    json["fileName"] = fileName;
    json["imgData"] = imgData;
    json["deviceID"] = "456"; // Replace with actual device ID
    json["end"] = "true"; // Assuming you want to upload to Drive

    qDebug() << "Sending image to server:";
    qDebug() << "File Name:" << fileName;
    qDebug() << "Device ID:" << json["deviceID"].toString();
    qDebug() << "Image Data Size:" << imgData.size() << "bytes";

    // Prepare request to server
    QUrl url("http://13.202.0.208:3010/savefile");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    // Send data to server using QNetworkAccessManager
    QNetworkAccessManager *manager = new QNetworkAccessManager(this);
    QNetworkReply *reply = manager->post(request, QJsonDocument(json).toJson());

    // Handle server response asynchronously
    connect(reply, &QNetworkReply::finished, [=]() {
        if (reply->error() == QNetworkReply::NoError) {
            qDebug() << "Server response:" << reply->readAll();
            // Handle successful response
        } else {
            qDebug() << "Error:" << reply->errorString();
            // Handle error
        }
        reply->deleteLater();
        manager->deleteLater();
    });
}




void MainWindow::display_topbar() {
    ui->msgbox->setText("");
    ui->top_prompt->hide();
}

void MainWindow::on_polarized_clicked()
{
    // Get the button that emitted the signal
    QPushButton *clickedButton = qobject_cast<QPushButton *>(sender());
    if (!clickedButton)
        return; // Ensure that the sender is a QPushButton

    static int imageIndex = 1; // Keep track of the current image index
    QStringList imagePaths = { ":/icons/icon_pol_selected.png", ":/icons/icon_linear_pol.png", ":/icons/icon_cross_pol.png"};

    // Set the button's icon
    clickedButton->setStyleSheet(QString("QPushButton { border-image: url(%1); background-color: transparent; }").arg(imagePaths[imageIndex]));
    qDebug() << "Setting button icon to" << imagePaths[imageIndex];

    // Execute commands based on the current image path
    if (imagePaths[imageIndex] == ":/icons/icon_pol_selected.png") {
        qDebug() << "No Polarization";
        int ret1 = system("echo 0 > /sys/class/gpio/gpio124/value");
        int ret2 = system("echo 0 > /sys/class/gpio/gpio83/value");
        qDebug() << "GPIO both set to 0, return values:" << ret1 << ret2;
        ui->top_prompt->raise();
        ui->top_prompt->show();
        QPropertyAnimation *animation = new QPropertyAnimation(ui->top_prompt, "geometry");
        animation->setDuration(100);
        QRect startRect = QRect(120, 0, ui->top_prompt->width(), ui->top_prompt->height());
        QRect endRect = QRect(120, 50, ui->top_prompt->width(), ui->top_prompt->height());
        animation->setStartValue(startRect);
        animation->setEndValue(endRect);

        QFont font("Product Sans", 24,QFont::Bold);
        ui->text->setFont(font);
        ui->text->setAlignment(Qt::AlignCenter);
        ui->text->setText("No\nPolarization");


        connect(animation, &QPropertyAnimation::finished, animation, &QPropertyAnimation::deleteLater);
        animation->start();
        timer_topbar->start(2000);

    } else if (imagePaths[imageIndex] == ":/icons/icon_linear_pol.png") {
        qDebug() << "Linear Polarization";
        int ret1 = system("echo 1 > /sys/class/gpio/gpio124/value");
        int ret2 = system("echo 0 > /sys/class/gpio/gpio83/value");
        qDebug() << "GPIO 124 set to 1, return values:" << ret1 << ret2;
        ui->top_prompt->raise();
        ui->top_prompt->show();
        QPropertyAnimation *animation = new QPropertyAnimation(ui->top_prompt, "geometry");
        animation->setDuration(100);
        QRect startRect = QRect(120, 0, ui->top_prompt->width(), ui->top_prompt->height());
        QRect endRect = QRect(120, 50, ui->top_prompt->width(), ui->top_prompt->height());
        animation->setStartValue(startRect);
        animation->setEndValue(endRect);
        QFont font("Product Sans", 24,QFont::Bold);
        ui->text->setFont(font);
        ui->text->setAlignment(Qt::AlignCenter);
        ui->text->setText("Linear\nPolarization");



        connect(animation, &QPropertyAnimation::finished, animation, &QPropertyAnimation::deleteLater);
        animation->start();
        timer_topbar->start(2000);

    } else if (imagePaths[imageIndex] == ":/icons/icon_cross_pol.png") {
        qDebug() << "Cross Polarization";
        int ret1 = system("echo 0 > /sys/class/gpio/gpio124/value");
        int ret2 = system("echo 1 > /sys/class/gpio/gpio83/value");
        qDebug() << "GPIO 83 set to 1, return values:" << ret1 << ret2;
        ui->top_prompt->raise();
        ui->top_prompt->show();
        QPropertyAnimation *animation = new QPropertyAnimation(ui->top_prompt, "geometry");
        animation->setDuration(100);
        QRect startRect = QRect(120, 0, ui->top_prompt->width(), ui->top_prompt->height());
        QRect endRect = QRect(120, 50, ui->top_prompt->width(), ui->top_prompt->height());
        animation->setStartValue(startRect);
        animation->setEndValue(endRect);
        QFont font("Product Sans", 24,QFont::Bold);
        ui->text->setFont(font);
        ui->text->setAlignment(Qt::AlignCenter);
        ui->text->setText("Cross\nPolarization");



        connect(animation, &QPropertyAnimation::finished, animation, &QPropertyAnimation::deleteLater);
        animation->start();
        timer_topbar->start(2000);
    }

    // Update the image index for the next click (cycle through the images)
    imageIndex = (imageIndex + 1) % imagePaths.size();
    qDebug() << "Next image index:" << imageIndex;
}

void MainWindow::on_gallery_clicked()
{
    ui->capture->setEnabled(false);
    ui->settings->setEnabled(false);

    // Toggle the visibility of the gallery frame
    if (galleryToFront) {
        ui->frame->lower(); // Lower the gallery frame
        ui->zoom->show();
    } else {
        ui->frame->raise(); // Raise the gallery frame
        ui->gallery->setStyleSheet("border:none;  image: url(:/icons/icon_gallery_selected.png); background-color: transparent;");
        ui->zoom->hide();
        ui->frame2->lower();
        ui->settings->setStyleSheet("border:none; image: url(:/icons/down.png); background-color: transparent;");
        settingsIconToggled = false;
    }

    // Directory path where the images are stored
    QString galleryPath = "/opt/Dermscope_v4/bin/results";

    // Check if the directory exists
    if (QDir(galleryPath).exists()) {
        // Get the list of image files in the directory
        QFileInfoList fileList = QDir(galleryPath).entryInfoList(QDir::Files, QDir::SortFlag::Name | QDir::SortFlag::Reversed);

        // Ensure currentIndex is within bounds
        if (currentIndex < 0) {
            currentIndex = 0;
        } else if (currentIndex >= fileList.size()) {
            currentIndex = fileList.size() - 1;
        }

        // Update the left and right buttons visibility
        ui->left->setVisible(currentIndex > 0);
        ui->right->setVisible(currentIndex < fileList.size() - 1);

        if (fileList.isEmpty()) {
            // Display a message indicating no images are available
            QPixmap transparentPixmap(ui->label2->size());
            transparentPixmap.fill(Qt::transparent);
            ui->label2->setPixmap(transparentPixmap);

            // Set text and font properties
            ui->label2->setText("NO IMAGE\nAVAILABLE");
            QFont font("Product Sans", 28);  // Specify "Product Sans" font with size 28
            font.setBold(true);  // Optionally set bold if needed
            ui->label2->setFont(font);
            ui->label2->setAlignment(Qt::AlignCenter);  // Set the alignment to center
        } else {
            // Load and display the image at the currentIndex
            QString imagePath = fileList[currentIndex].filePath();
            cv::Mat frame = cv::imread(imagePath.toStdString());

            if (!frame.empty()) {
                // Rotate the frame by 90 degrees clockwise
                //                cv::Mat rotatedFrame;
                //                cv::rotate(frame, rotatedFrame, cv::ROTATE_90_CLOCKWISE);

                //                // Resize the rotated frame to fit the QLabel size
                //                QSize targetSize = ui->label2->size();
                //                double fx = static_cast<double>(targetSize.width()) / rotatedFrame.rows;
                //                double fy = static_cast<double>(targetSize.height()) / rotatedFrame.cols;

                //                // Using minimum scaling factor to maintain aspect ratio
                //                double scale = std::min(fx, fy);
                //                cv::Mat resizedFrame;
                //                cv::resize(rotatedFrame, resizedFrame, cv::Size(), scale, scale, cv::INTER_LINEAR);

                //                // Rotate the resized frame again (if needed)
                //                cv::Mat doubleRotatedFrame;
                //                cv::rotate(resizedFrame, doubleRotatedFrame, cv::ROTATE_90_COUNTERCLOCKWISE);

                //                // Convert the double rotated frame to QImage
                //                QImage qimg((uchar*)doubleRotatedFrame.data, doubleRotatedFrame.cols, doubleRotatedFrame.rows, QImage::Format_RGB888);
                //                QPixmap pixmap = QPixmap::fromImage(qimg.rgbSwapped());

                QImage qimg((uchar*)frame.data, frame.cols, frame.rows, QImage::Format_RGB888);
                QPixmap pixmap = QPixmap::fromImage(qimg.rgbSwapped());
                // Display the double rotated frame
                ui->label2->setPixmap(pixmap.scaled(ui->label2->size(), Qt::KeepAspectRatio, Qt::FastTransformation));
                ui->label2->setText(""); // Clear any previous text
            } else {
                qDebug() << "Failed to load image: " << imagePath;
            }
        }
    } else {
        qDebug() << "Directory not found: " << galleryPath;
    }
}

void MainWindow::on_del_clicked()
{
    // Directory path where the images are stored
    QString galleryPath = "/opt/Dermscope_v4/bin/results";

    // Get the list of image files in the directory
    QFileInfoList fileList = QDir(galleryPath).entryInfoList(QDir::Files, QDir::SortFlag::Name | QDir::SortFlag::Reversed);

    // Check if fileList is not empty
    if (!fileList.isEmpty()) {
        // Get the file path of the current index
        QString filePath = fileList[currentIndex].filePath();

        // Remove the image file
        QFile file(filePath);
        if (file.remove()) {
            qDebug() << "Image deleted successfully: " << filePath;
        } else {
            qDebug() << "Error deleting image: " << filePath;
        }

        // Reload the gallery with the updated fileList
        on_gallery_clicked();
    } else {
        // Display a message indicating no images are available
        //        ui->prompt_2->setStyleSheet("color:rgb(246, 211, 45); background-color: rgba(0,0,0,100); font-size: 24px; font-family: Arial; font-weight: lighter;");
        //        ui->prompt_2->setText("No Images Available");

    }
}

void MainWindow::on_right_clicked()
{
    // Increment the currentIndex to navigate to the next image
    currentIndex++;
    qDebug() << "Current Index after right click: " << currentIndex;
    // Reload the gallery with the updated currentIndex
    on_gallery_clicked();
}

void MainWindow::on_left_clicked()
{
    // Decrement the currentIndex to navigate to the previous image
    currentIndex--;
    qDebug() << "Current Index after left click: " << currentIndex;
    // Reload the gallery with the updated currentIndex
    on_gallery_clicked();
}

void MainWindow::on_back_clicked()
{
    ui->gallery->setStyleSheet("border:none;  image: url(:/icons/icon_gallery.png); background-color: transparent;");
    currentIndex = 0;
    ui->frame->lower(); // Lower the gallery frame
    ui->settings->setEnabled(true);
    ui->zoom->show();
    ui->capture->setEnabled(true);



}

void MainWindow::on_settings_clicked()
{
    if (settingsIconToggled) {
        // Fix typo in the image URL
        ui->settings->setStyleSheet("border:none; image: url(:/icons/down.png); background-color: transparent;");
        ui->frame2->lower();
        ui->capture->raise();
        ui->capture->setEnabled(true);
    } else {
        ui->settings->setStyleSheet("border:none; image: url(:/icons/up.png); background-color: transparent;");
        ui->frame2->raise();
        ui->settings->raise();
        ui->capture->raise();
        ui->capture->setEnabled(true);
    }

    settingsIconToggled = !settingsIconToggled; // Toggle the state

    // Debug statement to check the current stylesheet
    qDebug() << "Current stylesheet:" << ui->settings->styleSheet();
}

void MainWindow::on_setgrid_clicked()
{
    // Toggle the icon
    QString iconPath = setgridIconToggled ? ":/icons/grid2.png" : ":/icons/grid.png";
    ui->setgrid->setIcon(QIcon(iconPath));
    ui->setgrid->setIconSize(QSize(70, 70)); // Ensure icon size is set

    qDebug() << "Setting button icon to" << iconPath;

    // Toggle the state
    setgridIconToggled = !setgridIconToggled;
    qDebug() << "New setgridIconToggled state: " << setgridIconToggled;

    // Toggle gridlabel pixmap or clear it based on state
    if (setgridIconToggled) {
        // Show grid image
        ui->gridlabel->setPixmap(QPixmap("/opt/Dermscope_v4/bin/icons/gridimg.png"));
    } else {
        // Clear gridlabel and set transparent background
        ui->gridlabel->clear();
        ui->gridlabel->setStyleSheet("background: transparent;");
    }
}

void MainWindow::on_zoom_clicked()
{
    // Enable zoombar
    ui->zoombar->setEnabled(true);

    // Toggle visibility of zoombar
    bool isVisible = ui->zoombar->isVisible();
    ui->zoombar->setVisible(!isVisible);

    if (ui->zoombar->isVisible()) {
        ui->zoombar->raise(); // Raise zoombar if it becomes visible
        ui->zoom->setStyleSheet("border:none; color: #fecc01; image: url(:/icons/zoom1.png); background-color: transparent;"); // Set text color to yellow

        // Hide other bars
        ui->brightness_bar->setVisible(false);
        ui->contrast_bar->setVisible(false);
        // Reset contrast icon and state
        ui->contrast->setIcon(QIcon(":/icons/icon_contrast.png"));
        ui->contrast->setIconSize(QSize(150, 70));
        contrastIconToggled = false;

        // Reset brightness icon and state
        ui->brightness->setIcon(QIcon(":/icons/icon_brightness.png"));
        ui->brightness->setIconSize(QSize(150, 70));
        brightnessIconToggled = false;
    } else {
        ui->zoom->setStyleSheet("border:none; color: white; image: url(:/icons/zoom1.png); background-color: transparent;"); // Set text color to white
    }
}

void MainWindow::on_zoombar_valueChanged(int value)
{
    // Ensure the scrollbar value is a multiple of 2
    int newValue = value;
    ui->zoombar->setValue(newValue);
    zoom = newValue / 10.0;
    QString buttonText = QString::number(zoom, 'f', 1) + "x"; // Concatenate 'x' after the zoom value
    ui->zoom->setText(buttonText);  // Set the text of the zoom button

    qDebug() << "Updated zoom value: " << zoom;
}

void MainWindow::datetime(){
    QTime currentTime = QTime::currentTime();
    QString formattedTime = currentTime.toString("h:mm AP");
    ui->date->setText(formattedTime);

}

//void MainWindow::on_sleep_mode_clicked()
//{
//    if (inSleepMode) {
//        // Exiting sleep mode: Initialize GPIOs and camera
//        system("echo 1 > /sys/class/gpio/gpio89/value");
//        qDebug() << "Entering sleep mode.";

//        if (!capture) {
//            int status = system("modprobe ov5645_camera_mipi_v2");
//            capture = new cv::VideoCapture(0);
//            if (!capture->isOpened()) {
//                qDebug() << "Error: Camera not detected!";
//            } else {
//                qDebug() << "Camera Initialized!";
//                capture->set(cv::CAP_PROP_FRAME_WIDTH, 640);
//                capture->set(cv::CAP_PROP_FRAME_HEIGHT, 480);
//                QTimer* timer = new QTimer(this);
//                connect(timer, &QTimer::timeout, this, &MainWindow::updateFrame);
//                timer->start(15);  // Update every 5 milliseconds
//            }
//        }

//        system("echo 124 > /sys/class/gpio/export");
//        system("echo 83 > /sys/class/gpio/export");
//        system("echo 96 > /sys/class/gpio/export");
//        system("echo 97 > /sys/class/gpio/export");
//        system("echo 88 > /sys/class/gpio/export");
//        system("echo 89 > /sys/class/gpio/export");
//        system("echo 132 > /sys/class/gpio/export");
//        system("echo \"out\" > /sys/class/gpio/gpio124/direction");
//        system("echo \"out\" > /sys/class/gpio/gpio83/direction");
//        system("echo \"in\" > /sys/class/gpio/gpio96/direction");
//        system("echo \"in\" > /sys/class/gpio/gpio97/direction");
//        system("echo \"in\" > /sys/class/gpio/gpio88/direction");
//        system("echo \"in\" > /sys/class/gpio/gpio89/direction");
//        system("echo falling > /sys/class/gpio/gpio96/edge");
//        system("echo falling > /sys/class/gpio/gpio97/edge");
//        system("echo falling > /sys/class/gpio/gpio88/edge");
//        system("echo falling > /sys/class/gpio/gpio89/edge");
//        system("echo falling > /sys/class/gpio/gpio124/edge");
//        qDebug() << "GPIOs turned active";
//        // Reset label2 properties for normal mode

//        ui->frame->lower(); // Lower the gallery frame
//        ui->settings->setEnabled(true);
//        ui->settings->show();
//        ui->capture->setEnabled(true);

//        ui->gridlabel->clear();

//        ui->frame2->show();
//        ui->frame->lower(); // Lower the gallery frame
//        ui->settings->setEnabled(true);
//        ui->settings->show();
//        ui->capture->setEnabled(true);
//        ui->zoombar->setEnabled(true);
//        ui->label->lower();
//        ui->label->clear();
//        ui->label->move(0, 50);
//        ui->label->setFixedSize(720, 1080);
//        ui->label->setStyleSheet(""); // Remove any custom styles
//        ui->zoom->show();
//        ui->polarized->show();ui->sleep_mode->show();




//        system("echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"); // Max freq
//        gpioset = true; // GPIOs are now set
//    } else {



//        // Entering sleep mode: Release GPIOs and camera
//        system("echo 124 > /sys/class/gpio/unexport");
//        system("echo 83 > /sys/class/gpio/unexport");
//        qDebug() << "LEDs turned off";
//        system("echo 96 > /sys/class/gpio/unexport");
//        system("echo 97 > /sys/class/gpio/unexport");
//        system("echo 88 > /sys/class/gpio/unexport");
//        system("echo 89 > /sys/class/gpio/unexport");
//        system("echo 132 > /sys/class/gpio/unexport");
//        qDebug() << "Navigations turned off";
//        if (timer->isActive()) {
//            timer->stop();}
//        if (capture && capture->isOpened()) {
//            capture->release();
//            delete capture;
//            capture = nullptr;
//            qDebug() << "Camera Released!";
//        } else {
//            qDebug() << "Camera was not initialized or already released!";
//        }

//        system("echo powersave > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"); // Powersave mode
//        qDebug() << "Slowed clock frequency";
//        //        ui->settings->setIcon(QIcon("/opt/Dermscope_v4/bin/icons/icon_set.png"));
//        ui->frame2->lower();
//        settingsIconToggled = false;
//        ui->label->raise();
//        ui->settings->hide();
//        ui->zoombar->setVisible(false);
//        //        ui->zoom->hide();
//        //        ui->polarized->hide();ui->sleep_mode->hide();

//        ui->label->setText("In Sleep Mode");
//        ui->label->move(0, 0);
//        ui->label->setFixedSize(720, 1280);
//        ui->label->setStyleSheet(
//                    "color: rgb(0,0,0);"
//                    "font-size: 28px;"
//                    "background-color: rgb(0,0,0);"
//                    );
//        gpioset = false; // GPIOs are now unset
//    }

//    inSleepMode = !inSleepMode; // Toggle sleep mode state


//}

//void MainWindow::wake_up()
//{
//    if (inSleepMode) {
//        system("echo 0 > /sys/class/gpio/gpio89/value");
//        qDebug() << "Exiting sleep mode.";
//        on_sleep_mode_clicked(); // Call on_sleep_mode_clicked to reinitialize the camera and GPIOs
//    }
//    inSleepMode = false; // Set sleep mode state to false
//}


void MainWindow::on_sleep_mode_clicked()
{
    if (inSleepMode) {
        wake_up();
    } else {

        // Entering sleep mode: Release GPIOs and camera
        system("echo 124 > /sys/class/gpio/unexport");
        system("echo 83 > /sys/class/gpio/unexport");
        qDebug() << "LEDs turned off";
        system("echo 96 > /sys/class/gpio/unexport");
        system("echo 97 > /sys/class/gpio/unexport");
        system("echo 88 > /sys/class/gpio/unexport");
//        system("echo 89 > /sys/class/gpio/unexport");
        system("echo 132 > /sys/class/gpio/unexport");
        qDebug() << "Navigations turned off";
        if (timer->isActive()) {
            timer->stop();}
        if (capture && capture->isOpened()) {
            capture->release();
            delete capture;
            capture = nullptr;
            qDebug() << "Camera Released!";
        } else {
            qDebug() << "Camera was not initialized or already released!";
        }

        system("echo powersave > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"); // Powersave mode
        qDebug() << "Slowed clock frequency";
        //        ui->settings->setIcon(QIcon("/opt/Dermscope_v4/bin/icons/icon_set.png"));
        ui->frame2->lower();
        settingsIconToggled = false;
        ui->label->raise();
        ui->settings->hide();
        ui->zoombar->setVisible(false);
        //        ui->zoom->hide();
        //        ui->polarized->hide();ui->sleep_mode->hide();

        ui->label->setText("In Sleep Mode");
        ui->label->move(0, 0);
        ui->label->setFixedSize(720, 1280);
        ui->label->setStyleSheet(
                    "color: rgb(0,0,0);"
                    "font-size: 28px;"
                    "background-color: rgb(0,0,0);"
                    );
        gpioset = false; // GPIOs are now unset        inSleepMode = true; // Set sleep mode state to true
          inSleepMode = true;
    }
}

void MainWindow::wake_up()
{
    if (inSleepMode) {
        if (!capture) {
            int status = system("modprobe ov5645_camera_mipi_v2");
            capture = new cv::VideoCapture(0);
            if (!capture->isOpened()) {
                qDebug() << "Error: Camera not detected!";
            } else {
                qDebug() << "Camera Initialized!";
                capture->set(cv::CAP_PROP_FRAME_WIDTH, 640);
                capture->set(cv::CAP_PROP_FRAME_HEIGHT, 480);
                QTimer* timer = new QTimer(this);
                connect(timer, &QTimer::timeout, this, &MainWindow::updateFrame);
                timer->start(15);  // Update every 5 milliseconds
            }
        }


        system("echo 124 > /sys/class/gpio/export");
        system("echo 83 > /sys/class/gpio/export");
        system("echo 96 > /sys/class/gpio/export");
        system("echo 97 > /sys/class/gpio/export");
        system("echo 88 > /sys/class/gpio/export");
        system("echo 89 > /sys/class/gpio/export");
        system("echo 132 > /sys/class/gpio/export");
        system("echo \"out\" > /sys/class/gpio/gpio124/direction");
        system("echo \"out\" > /sys/class/gpio/gpio83/direction");
        system("echo \"in\" > /sys/class/gpio/gpio96/direction");
        system("echo \"in\" > /sys/class/gpio/gpio97/direction");
        system("echo \"in\" > /sys/class/gpio/gpio88/direction");
        system("echo \"in\" > /sys/class/gpio/gpio89/direction");
        system("echo falling > /sys/class/gpio/gpio96/edge");
        system("echo falling > /sys/class/gpio/gpio97/edge");
        system("echo falling > /sys/class/gpio/gpio88/edge");
        system("echo falling > /sys/class/gpio/gpio89/edge");
        system("echo falling > /sys/class/gpio/gpio124/edge");
        qDebug() << "GPIOs turned active";
        // Reset label2 properties for normal mode


        ui->frame->lower(); // Lower the gallery frame
        ui->settings->setEnabled(true);
        ui->settings->show();
        ui->capture->setEnabled(true);

        ui->gridlabel->clear();

        ui->frame2->show();
        ui->frame->lower(); // Lower the gallery frame
        ui->settings->setEnabled(true);
        ui->settings->show();
        ui->capture->setEnabled(true);
        ui->zoombar->setEnabled(true);
        ui->label->lower();
        ui->label->clear();
        ui->label->move(0, 50);
        ui->label->setFixedSize(720, 1080);
        ui->label->setStyleSheet(""); // Remove any custom styles
        ui->zoom->show();
        ui->polarized->show();ui->sleep_mode->show();




        system("echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"); // Max freq
        gpioset = true; // GPIOs are now set
        inSleepMode = false; // Set sleep mode state to false
    }
}



void MainWindow::gpio89Changed()
{
    static QTimer timer; // Static timer to maintain state between function calls
    timer.setSingleShot(true); // Set timer to single-shot mode

    QFile file("/sys/class/gpio/gpio89/value");
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream in(&file);
        QString value = in.readLine().trimmed();
        file.close();
        qDebug() << "GPIO 89 value changed to:" << value;

        if (value == "1") {
            // Start or restart the timer for 5 seconds when GPIO 89 becomes 1
            timer.start(5000);

            // Connect timeout directly to lambda for handling sleep mode
            QObject::connect(&timer, &QTimer::timeout, this, [this]() {
                qDebug() << "GPIO 89 remained '1' for 5 seconds. Entering sleep mode.";
                on_sleep_mode_clicked();
            });
        } else {
            // Stop the timer if GPIO 89 goes back to 0
            timer.stop();
            wake_up();
        }
    }
}


void MainWindow::mousePressEvent(QMouseEvent *event)
{
    // Check if the application is in sleep mode
    if (inSleepMode) {
        wake_up();
        return; // Exit early since we just woke up
    }
    // Check if the zoom bar is visible and the mouse press event occurs outside the zoom bar
    if (ui->zoombar->isVisible() && !ui->zoombar->geometry().contains(event->pos())) {
        ui->zoombar->setVisible(false);
        ui->zoom->setStyleSheet("border:none; color: white; image: url(:/icons/zoom1.png); background-color: transparent;");
        qDebug() << "Zoom bar hidden.";
    }

    // If not in sleep mode, handle the click as usual
    QMainWindow::mousePressEvent(event);

    // Log the position of the mouse click for debugging purposes
    qDebug() << "Mouse pressed at position:" << event->pos();
}

void MainWindow::on_wifi_clicked()
{    std::string token, ssid, password;
     std::string essidInfo = "";

      Mat gray_img = frame;
       cvtColor(frame, gray_img, COLOR_BGR2GRAY);
        QRCodeDetector qrDet;
         std::string qrCodeDataStdString = qrDet.detectAndDecode(gray_img);
          qrCodeData = QString::fromStdString(qrCodeDataStdString);
           qDebug() << "QR Info: " << qrCodeData;

            if (qrCodeData.isEmpty()) {
                qDebug() << "inside empty";
                ui->top_prompt->raise();
                ui->top_prompt->show();
                QPropertyAnimation *animation = new QPropertyAnimation(ui->top_prompt, "geometry");
                animation->setDuration(100);
                QRect startRect = QRect(120, 0, ui->top_prompt->width(), ui->top_prompt->height());
                QRect endRect = QRect(120, 50, ui->top_prompt->width(), ui->top_prompt->height());
                animation->setStartValue(startRect);
                animation->setEndValue(endRect);
                QFont font("Product Sans", 24,QFont::Bold);
                ui->text->setFont(font);
                ui->text->setAlignment(Qt::AlignCenter);
                ui->text->setText("No QR Code Detected");
                animation->start();
                timer_topbar->start(2000);
            } else {
                std::istringstream ss(qrCodeDataStdString);

                // Parse the Wi-Fi network configuration string
                std::string qrCodeDataStdString = qrCodeData.toStdString();


                while (getline(ss, token, ';')) {
                    if (token.find("S:") != std::string::npos) {
                        ssid = token.substr(token.find("S:") + 2);
                    } else if (token.find("P:") != std::string::npos) {
                        password = token.substr(token.find("P:") + 2);
                    }
                }

                std::ofstream configFile("/etc/wpa_supplicant.conf");
                if (configFile.is_open()) {
                    configFile << "network={\n";
                    configFile << "    ssid=\"" << ssid << "\"\n";
                    configFile << "    psk=\"" << password << "\"\n";
                    configFile << "}\n";
                    configFile.close();
                }

                FILE* pipe = popen("iwconfig", "r");
                if (!pipe) {
                    std::cerr << "Error: Failed to execute iwconfig command" << std::endl;
                }
                char buffer[256];
                while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
                    if (strstr(buffer, "ESSID") != NULL) {
                        char* essidStart = strstr(buffer, "ESSID:\"") + strlen("ESSID:\"");
                        char* essidEnd = strchr(essidStart, '\"');
                        *essidEnd = '\0';
                        essidInfo = essidStart;
                        break;
                    }
                }
                pclose(pipe);
                std::cout << "ESSID: " << essidInfo << std::endl;

                if (essidInfo == ssid) {
                    qDebug() << "Mubaarkaan";
                    ui->top_prompt->raise();
                    ui->top_prompt->show();
                    QPropertyAnimation *animation = new QPropertyAnimation(ui->top_prompt, "geometry");
                    animation->setDuration(100);
                    QRect startRect = QRect(120, 0, ui->top_prompt->width(), ui->top_prompt->height());
                    QRect endRect = QRect(120, 50, ui->top_prompt->width(), ui->top_prompt->height());
                    animation->setStartValue(startRect);
                    animation->setEndValue(endRect);

                    QFont font("Product Sans",20 ,QFont::Bold);
                    ui->text->setFont(font);
                    ui->text->setAlignment(Qt::AlignCenter);
                    ui->text->setText("Network Connection\nSUCCESSFUL");

                    animation->start();
                    timer_topbar->start(15000);
                    //                    ui->wifi_connected->show();
                    ui->wifi_connected->setPixmap(QPixmap(("/opt/Dermscope_v4/bin/icons/icon_wifi.png")));
                } else {
                    qDebug() << "Try again damn";
                    ui->top_prompt->raise();
                    ui->top_prompt->show();
                    QPropertyAnimation *animation = new QPropertyAnimation(ui->top_prompt, "geometry");
                    animation->setDuration(100);
                    QRect startRect = QRect(120, 0, ui->top_prompt->width(), ui->top_prompt->height());
                    QRect endRect = QRect(120, 50, ui->top_prompt->width(), ui->top_prompt->height());
                    animation->setStartValue(startRect);
                    animation->setEndValue(endRect);
                    QFont font("Product Sans", 24,QFont::Bold);
                    ui->text->setFont(font);
                    ui->text->setAlignment(Qt::AlignCenter);
                    ui->text->setText("Network Connection\nFAILED");


                    animation->start();
                    timer_topbar->start(15000);
                    //                    ui->wifi_connected->hide();
                    ui->wifi_connected->setPixmap(QPixmap(("/opt/Dermscope_v4/bin/icons/icon_wifi.png")));
                    //                    timer_prompt->start(1200);
                }
                int status = system("sudo systemctl restart inventron-init.service");
                if (status == 0) {
                    qDebug() << "Network Connection\nSUCCESSFUL";
                } else {
                    qDebug() << "Network Connection\nFailed";
                }
            }
}

void MainWindow::checkConnection()
{
    // Convert QString to std::string
    std::string qrCodeDataStdString = qrCodeData.toStdString();
    std::istringstream ss(qrCodeDataStdString);
    qDebug() << "QR Info: " << qrCodeData;

    std::string token, ssid, password;

    while (std::getline(ss, token, ';')) {
        if (token.find("S:") != std::string::npos) {
            ssid = token.substr(token.find("S:") + 2);
        } else if (token.find("P:") != std::string::npos) {
            password = token.substr(token.find("P:") + 2);
        }
    }

    std::ifstream configFile("/etc/wpa_supplicant.conf");

    // Check if the file is opened successfully
    if (configFile.is_open()) {
        std::string line;

        // Read each line from the file
        while (std::getline(configFile, line)) {
            // Check if the line contains the SSID
            size_t pos = line.find("ssid=\"");
            if (pos != std::string::npos) {
                // Extract the SSID
                ssid = line.substr(pos + 6); // 6 is the length of "ssid=\""
                ssid = ssid.substr(0, ssid.find('"')); // Extracting the SSID until the next double quote
                break; // Stop reading further after finding the SSID
            }
        }

        // Close the file
        configFile.close();

        // Checking ESSID
        FILE* pipe = popen("iwconfig", "r");
        if (!pipe) {
            std::cerr << "Error: Failed to execute iwconfig command" << std::endl;
            return; // Exit if popen failed
        }

        // Buffer to store each line of output
        char buffer[256];
        // Read output line by line
        while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
            // Check if the line contains ESSID information
            if (strstr(buffer, "ESSID") != NULL) {
                // Extract ESSID information
                char* essidStart = strstr(buffer, "ESSID:\"") + strlen("ESSID:\"");
                char* essidEnd = strchr(essidStart, '\"');
                if (essidEnd) {
                    *essidEnd = '\0'; // Null-terminate the string
                    essidInfo = essidStart;
                }
                break; // Exit loop after finding ESSID
            }
        }
        pclose(pipe);
        std::cout << "ESSID: " << essidInfo << std::endl;

        if (essidInfo == ssid) {
            qDebug() << "Still connected";
            ui->wifi_connected->show();
            //             ui->wifi_connected->setPixmap(QPixmap(("/opt/Dermscope_v4/bin/icons/icon_wifi_selected.png")));
        } else {
            qDebug() << "Disconnected hm";
            ui->wifi_connected->hide();
            //             ui->wifi_connected->setPixmap(QPixmap(("/opt/Dermscope_v4/bin/icons/icon_wifi.png")));
        }
    } else {
        std::cerr << "Error : Failed to open configuration file" << std::endl;
    }
}

void MainWindow::on_brightness_clicked()
{

    // Toggle the icon
    QString iconPath = brightnessIconToggled ? ":/icons/icon_brightness.png" : ":/icons/icon_brightness_selected.png";
    ui->brightness->setIcon(QIcon(iconPath));
    ui->brightness->setIconSize(QSize(150, 70)); // Ensure icon size is set
    qDebug() << "Setting brightness button icon to" << iconPath;

    // Toggle the state
    brightnessIconToggled = !brightnessIconToggled;
    qDebug() << "New brightnessIconToggled state: " << brightnessIconToggled;

    // Toggle visibility of brightness_bar
    ui->brightness_bar->setVisible(brightnessIconToggled);

    if (brightnessIconToggled) {
        // Hide other bars
        ui->contrast_bar->setVisible(false);
        ui->zoombar->setVisible(false);
        // Reset contrast icon and state
        ui->contrast->setIcon(QIcon(":/icons/icon_contrast.png"));
        ui->contrast->setIconSize(QSize(150, 70));
        contrastIconToggled = false;
        ui->zoom->setStyleSheet("border:none; color: white; image: url(:/icons/zoom1.png); background-color: transparent;"); // Set text color to white

        // Set properties for ui->brightness_bar if it's visible and not initialized
        if (!brightnessBarInitialized) {
            ui->brightness_bar->setMinimum(0);      // Minimum value for brightness
            ui->brightness_bar->setMaximum(18);     // Maximum value for brightness
            ui->brightness_bar->setSingleStep(1);   // Increment or decrement step
            ui->brightness_bar->setPageStep(4);     // Page step

            // Set initial value based on current brightness value (converted to int)
            //            ui->brightness_bar->setValue(8);

            // Additional properties
            ui->brightness_bar->setTracking(true);          // Disable tracking
            ui->brightness_bar->setInvertedAppearance(true); // Invert appearance for brightness bar
            ui->brightness_bar->setInvertedControls(true);   // Invert control direction

            brightnessBarInitialized = true; // Mark the bar as initialized
        }
    }
}

void MainWindow::updateBrightness(int value)
{
    // Only update brightness if the slider value changes
    if (value != ui->brightness_bar->value())
        return;

    double newBrightness = static_cast<double>(value) * 10 - 70;

    // Adjust brightness based on scrollbar movement
    if (newBrightness < brightness) {
        brightness = newBrightness - 10;
        if (brightness < -70) brightness = -70; // Limit brightness to minimum value
    } else {
        brightness = newBrightness + 10;
        if (brightness > 70) brightness = 70;   // Limit brightness to maximum value
    }

    // Debug output to verify the value and brightness adjustments
    qDebug() << "Scrollbar value changed to:" << value;
    qDebug() << "New brightness value:" << brightness;
}

void MainWindow::on_contrast_clicked()
{
    // Toggle the icon
    QString iconPath = contrastIconToggled ? ":/icons/icon_contrast.png" : ":/icons/icon_contrast_selected.png";
    ui->contrast->setIcon(QIcon(iconPath));
    ui->contrast->setIconSize(QSize(150, 70)); // Ensure icon size is set
    qDebug() << "Setting contrast button icon to" << iconPath;

    // Toggle the state
    contrastIconToggled = !contrastIconToggled;
    qDebug() << "New contrastIconToggled state: " << contrastIconToggled;

    // Toggle visibility of contrast_bar
    ui->contrast_bar->setVisible(contrastIconToggled);

    if (contrastIconToggled) {
        // Hide other bars
        ui->brightness_bar->setVisible(false);
        ui->zoombar->setVisible(false);


        // Reset brightness icon and state
        ui->brightness->setIcon(QIcon(":/icons/icon_brightness.png"));
        ui->brightness->setIconSize(QSize(150, 70));
        brightnessIconToggled = false;
        ui->zoom->setStyleSheet("border:none; color: white; image: url(:/icons/zoom1.png); background-color: transparent;"); // Set text color to white

        // Set properties for ui->contrast_bar if it's visible and not initialized
        if (!contrastBarInitialized) {
            ui->contrast_bar->setMinimum(1);      // Minimum value for contrast
            ui->contrast_bar->setMaximum(20);     // Maximum value for contrast
            ui->contrast_bar->setSingleStep(1);   // Increment or decrement step
            ui->contrast_bar->setPageStep(4);     // Page step

            // Set initial value based on current contrast value (converted to int)
            ui->contrast_bar->setValue(static_cast<int>(contrast * 10));

            // Additional properties
            ui->contrast_bar->setTracking(true);          // Disable tracking
            ui->contrast_bar->setInvertedAppearance(true); // Invert appearance for contrast bar
            ui->contrast_bar->setInvertedControls(true);   // Invert control direction

            contrastBarInitialized = true; // Mark the bar as initialized
        }
    }
}

void MainWindow::updateContrast(int value)
{
    double newContrast = static_cast<double>(value) / 10.0;

    // Adjust contrast based on scrollbar movement
    if (newContrast < contrast) {
        contrast = newContrast - 0.1;
        if (contrast < 0.5) contrast = 0.5;
    } else {
        contrast = newContrast + 0.1;
        if (contrast > 2.0) contrast = 2.0;
    }

    // Debug output to verify the value and contrast adjustments
    qDebug() << "Scrollbar value changed to:" << value;
    qDebug() << "New contrast value:" << contrast;
}


//////////////////////////////////////////////////////////////////////
/// i2c library for reading data
//////////////////////////////////////////////////////////////////////
void MainWindow::openI2C()
{
    i2cFile = open("/dev/i2c-2", O_RDWR);
    if (i2cFile < 0) {
        qWarning() << "Failed to open I2C bus";
        return;
    }
    qDebug() << "I2C bus opened successfully.";

    if (ioctl(i2cFile, I2C_SLAVE,max17043_address) < 0) {
        qWarning() << "Failed to acquire bus access and/or talk to slave";
        closeI2C(); // Close the file descriptor if setting the slave address fails
        return;
    }
    qDebug() << "Slave address set to 0x" << QString::number(max17043_address, 16);
}

void MainWindow::closeI2C()
{
    if (i2cFile >= 0) {
        //        close(i2cFile);
        i2cFile = -1;
    }
}

int MainWindow::readI2CInteger(uint8_t reg)
{
    if (i2cFile < 0) {
        qWarning() << "I2C file not open";
        return -1;
    }

    uint8_t buf[2];
    buf[0] = reg;
    if (write(i2cFile, buf, 1) != 1) {
        qWarning() << "Failed to write register address to the I2C bus. Error:" << strerror(errno);
        return -1;
    }

    if (read(i2cFile, buf, 2) != 2) {
        qWarning() << "Failed to read from the I2C bus. Error:" << strerror(errno);
        return -1;
    }

    int data = (buf[0] << 8) | buf[1];
    return data;
}

void MainWindow::writeI2CRegister(uint8_t reg, uint16_t value)
{
    if (i2cFile < 0) {
        qWarning() << "I2C file not open";
        return;
    }

    uint8_t buf[3];
    buf[0] = reg;
    buf[1] = value >> 8;
    buf[2] = value & 0xFF;
    if (write(i2cFile, buf, 3) != 3) {
        qWarning() << "Failed to write to the I2C bus. Error:" << strerror(errno);
        return;
    }
}

float MainWindow::readVoltage()
{
    int vcell = readI2CInteger(MAX17043_VCELL);
    if (vcell < 0)
        return -1.0f;

    return 1.25f * static_cast<float>(vcell >> 4);
}

float MainWindow::readPercentage()
{
    int soc = readI2CInteger(MAX17043_SOC);
    if (soc < 0)
        return -1.0f;

    return (soc >> 8) + 0.003906f * (soc & 0xFF);
}

int MainWindow::initializeMAX17043()
{
    // Power on reset
    writeI2CRegister(MAX17043_COMMAND, 0x5400);
    QThread::msleep(10); // Adjust delay as per your device's requirements

    // Verify configuration
    qDebug() << "Config Register:" << QString::number(readI2CInteger(MAX17043_CONFIG), 16);
    if (readI2CInteger(MAX17043_CONFIG) == 0x971c) {
        // Configure for quick start
        writeI2CRegister(MAX17043_MODE, 0x4000);
        writeI2CRegister(MAX17043_CONFIG, 0x9700);
        qDebug() << "Config Register after setting:" << QString::number(readI2CInteger(MAX17043_CONFIG), 16);
        QThread::msleep(10); // Adjust delay as per your device's requirements
        return 0;
    }
    return -1;
}

void MainWindow::updateBatteryInfo()
{
    float voltage = readVoltage();
    float percentageValue = readPercentage();

    if (voltage >= 0 && percentageValue >= 0) {
        qDebug() << "Voltage:" << voltage << "V, Percentage:" << QString::number(percentageValue, 'f', 2) + "%";
        ui->percentage->setText(QString::number(static_cast<int>(percentageValue)) + "%");
    } else {
        qWarning() << "Failed to read voltage or percentage from MAX17043.";
        ui->percentage->setText("Error reading percentage");
    }
}









//[core]
//use-g2d=1
//repaint-window=16
//idle-time=0
//xwayland=true
//#gbm-format=argb8888
//#enable-overlay-view=1

//[shell]
//panel-position=none
//panel-location=none
//panel-color=0x90A00000
//locking=false
//use-g2d=1
//xwayland=true
//background-image=/userarea/init/inventron.jpg
//#size=480x800

//[libinput]
//touchscreen_calibrator=true

//[output]
//#name=HDMI-A-1
//#mode=480x800@60
//#transform=rotate-90

//#[output]
//#name=HDMI-A-2
//#mode=on
//#	WIDTHxHEIGHT    Resolution size width and height in pixels
//#	off             Disables the output
//#	preferred	Uses the preferred mode
//#	current         Uses the current crt controller mode
//#transform=rotate-90

//[screen-share]
//command=/usr/bin/weston --backend=rdp-backend.so --shell=fullscreen-shell.so --no-clients-resize
//#start-on-startup=true

//cd /sys/class/drm/card1-HDMI-A-1











