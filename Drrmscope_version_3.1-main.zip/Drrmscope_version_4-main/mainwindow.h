#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QImage>
#include <QPixmap>
#include <QKeyEvent>
#include <QCoreApplication>
#include <QApplication>
#include <QFileInfo>
#include <QDir>
#include <QDateTime>
#include <QDebug>
#include <QProcessEnvironment>
#include <QTimer>
#include <QIcon>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdio> // For popen and pclose
#include <cstring> // For strstr and strchr

#include <opencv2/opencv.hpp>
#include <opencv2/objdetect.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <QMessageBox>
#include <QFileSystemWatcher>
#include <QPropertyAnimation>
#include <QElapsedTimer>

#include <QWidget>
#include <QTouchEvent>
#include <QList>
#include <QResizeEvent>

#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>
#include <errno.h>
#include <QString>
#include <QThread>  // For QThread::msleep


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
  void sendImageToServer(const QString &fileName, const cv::Mat &processedFrame);


private slots:
    void updateFrame();
    void on_capture_clicked();
    void display_topbar();
    void datetime();
    void on_polarized_clicked();
    void on_gallery_clicked();
    void on_right_clicked();
    void on_left_clicked();
    void on_back_clicked();
    void on_del_clicked();
    void on_settings_clicked();
    void on_setgrid_clicked();
    void on_zoom_clicked();
    void on_zoombar_valueChanged(int value);
    void checkConnection();
    void wake_up();
    void on_sleep_mode_clicked();
    void on_wifi_clicked();
    void updateNtpConf();
    void setTimeZone();
    void on_brightness_clicked();
    void updateBrightness(int value);
    void updateContrast(int value);
    void updateFPS();
    void on_contrast_clicked();
    void updateBatteryInfo(); // Slot to update battery info periodically

private:
    std::string essidInfo;
    std::string ssid;
    std::string password;
    std::string token;
    cv::Mat frame;
    QString qrCodeData;
    Ui::MainWindow *ui;
    cv::VideoCapture *capture;
    cv::Mat rotatedFrame;
    cv::Mat processedFrame;
    QTimer *timer_prompt;
    QTimer *timer_prompt2;
    QTimer *timer_date;
    QTimer *timer;
    QTimer *checkTimer;
    QTimer *timer_topbar;
    bool inSleepMode = false;
    void setupSystem();
    void setupGPIO();
    void setupCamera();
    void setupTimers();
    bool scrollbarVisible;
    bool settingsIconToggled;  // Declare the member variable
    bool gridToggled;
    bool setgridIconToggled;;
    QTimer *fpsTimer;
    QElapsedTimer elapsedTimer;
    int frameCount;
    double currentFPS;
    bool contrastIconToggled = false;
    bool brightnessIconToggled = false;
    double contrast = 1.0;
    double brightness = 0.0;
    bool contrastBarInitialized = false;
    bool brightnessBarInitialized = false;



    ///for i2c
    int i2cFile;
    const char *i2cDevice = "/dev/i2c-2";
    uint8_t max17043_address = 0x36; // MAX17043 I2C address
    void openI2C();
    void closeI2C();
    int readI2CInteger(uint8_t reg);
    void writeI2CRegister(uint8_t reg, uint16_t value);
    float readVoltage();
    float readPercentage();
    int initializeMAX17043();


    void gpio89Changed();
        QFileSystemWatcher watcher_sleep;
         QTimer gpioTimer;

protected:
    void mousePressEvent(QMouseEvent *event) override;
};
#endif // MAINWINDOW_H
