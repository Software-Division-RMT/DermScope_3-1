#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QImage>
#include <QPixmap>
#include <QCoreApplication>
#include <QApplication>
#include <QTime>
#include <QDir>
#include <QElapsedTimer>
#include <QTimer>
#include <QThread>
#include <iostream>
#include <QProcess>
#include <fstream>
#include <opencv2/opencv.hpp>
#include <opencv2/objdetect.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>
#include <QFileSystemWatcher>
#include <QFont>
#include <QMouseEvent>
#include <QPropertyAnimation>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QFile>
#include <QByteArray>
#include <QList>
#include <QBuffer>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>  // Include QJsonArray for handling JSON arrays
#include <QTimeZone>


// Constants for MAX17043 registers
#define MAX17043_VCELL      0x02  // Voltage cell register
#define MAX17043_SOC        0x04  // State of Charge register
#define MAX17043_CONFIG     0x0C  // Config register
#define MAX17043_MODE       0x06  // Mode register
#define MAX17043_COMMAND    0xFE  // Command register

const int GPIO_118 = 118;
const int GPIO_124 = 124;
const int GPIO_83 = 83;
const int GPIO_97 = 97;
const int GPIO_96 = 96;
const int GPIO_88 = 88;
const int GPIO_89 = 89;
const int GPIO_132 = 132;

// I2C bus and device address
#define I2C_BUS             "/dev/i2c-1"
#define DEVICE_ADDRESS    0x36
bool gpioset=true;

float voltage=0;
float prev=0;
int ctr=0;

using namespace cv;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , capture(new cv::VideoCapture())
    , timer_10(new QTimer(this))
    , timer_60000(new QTimer(this))
    , checkTimer(new QTimer(this))
    , timeri2c(new QTimer(this))
    , timer_pol(new QTimer(this))
    , standbyTimer(new QTimer(this))
    , flag_capture(false)
    , flag_wifi(false)
    , plane(0)
    , slide_id(0)
    , val_galleryindex(0)
    , val_zoom(1.0)
    , val_contrast(1.2)
    , val_brightness(-20)
    , contrast_toggle(false)
    , brightness_toggle(false)
    , polarization_toggle(0)
    , gridtoggle(false)
    , inSleepMode(false)
    , zoom_toggle(false)
    , zoom_toggle2(false)
    ,standbymode(false)

{
    /***** Application Begin *****/

    ui->setupUi(this);
    ui->icon_prompt->hide();
    setCursor(Qt::BlankCursor);
    ui->wifi_icon->hide();
    setupGPIO();
    updateNtpConf();
    init_sys();
    init_timers();
    init_screen1();
    init_camera();

    /***** Application End *****/


}


void MainWindow::setupGPIO()
{
    //sleep
    system("echo 89 > /sys/class/gpio/export");
    system("echo \"in\" > /sys/class/gpio/gpio89/direction");
    system("echo falling > /sys/class/gpio/gpio89/edge");
    //polarization
    system("echo 83 > /sys/class/gpio/export");
    system("echo \"in\" > /sys/class/gpio/gpio83/direction");
    system("echo falling > /sys/class/gpio/gpio83/edge");

    system("echo 124 > /sys/class/gpio/export");
    system("echo \"out\" > /sys/class/gpio/gpio124/direction");
    system("echo 1 > /sys/class/gpio/gpio124/value");
    timer_pol->start(1.0);
    system("echo 0 > /sys/class/gpio/gpio124/value");
    timer_pol->start(2000);
    //capture
    system("echo 96 > /sys/class/gpio/export");
    system("echo \"in\" > /sys/class/gpio/gpio96/direction");
    system("echo falling > /sys/class/gpio/gpio96/edge");

    watcher_sleep.addPath("/sys/class/gpio/gpio89/value");
    connect(&watcher_sleep, &QFileSystemWatcher::fileChanged, this, &MainWindow::sleepbygpio);

    watcher_capture.addPath("/sys/class/gpio/gpio96/value");
    connect(&watcher_capture, &QFileSystemWatcher::fileChanged, this, &MainWindow::captureImagebygpio);

    watcher_polarize.addPath("/sys/class/gpio/gpio83/value");
    connect(&watcher_polarize, &QFileSystemWatcher::fileChanged, this, &MainWindow::polarizebygpio);




    // Print out all added paths for verification
    QStringList paths = watcher_sleep.files();


}

void MainWindow::init_camera()
{
    int status = system("modprobe ov5645_camera_mipi_v2");
    if (status != 0) {

        return;
    }


    capture->open(0);
    if (!capture->isOpened()) {

        return;
    }

    capture->set(cv::CAP_PROP_FRAME_WIDTH, 640);
    capture->set(cv::CAP_PROP_FRAME_HEIGHT, 480);
    capture->set(cv::CAP_PROP_FPS, 30);
}

void MainWindow::init_sys()
{
    QString galleryPath = QDir::currentPath() + "/gallery/";
    QDir dir(galleryPath);

    if (!dir.exists()) {
        dir.mkpath(galleryPath);
    }

    QFileInfoList fileList = QDir(galleryPath).entryInfoList(QDir::Files, QDir::SortFlag::Name);
    val_galleryindex = fileList.size() - 1;

    QFont font28("Product Sans", 28);
    ui->label_datetime->setFont(font28);
    ui->label_battery->setFont(font28);
    ui->button_C->setFont(font28);
    ui->bg_opt->setFont(font28);

    std::ofstream configFile("/etc/resolv.conf");
    if (configFile.is_open())
    {
        configFile << "nameserver 8.8.8.8\nnameserver 8.8.4.4";
    }

    setTimeZone();

    system("sudo systemctl enable ntpd.service");
    system("sudo systemctl restart ntpd.service");
    system("sudo systemctl restart ntpdate.service");
    system("sudo ntpdate 0.pk.pool.ntp.org");
    system("sudo systemctl disable ntpd.service");

    openI2C();
    if (initializeMAX17043() == 0) {

    } else {
        qWarning() << "Failed to initialize MAX17043.";
    }

}

void MainWindow::init_timers()
{
    connect(timer_10, &QTimer::timeout, this, &MainWindow::update_screen1);

    connect(timer_60000, &QTimer::timeout, this, &MainWindow::update_datetime);
    timer_60000->start(60000);

    connect(checkTimer, &QTimer::timeout, this, &MainWindow::checkConnection);
    checkTimer->start(60000);

    connect(timeri2c, &QTimer::timeout, this, &MainWindow::updateBatteryInfo);
    timeri2c->start(500);

    connect(timer_pol, &QTimer::timeout,this, &MainWindow::close_polarization);

    timer_topbar = new QTimer(this);
    connect(timer_topbar, SIGNAL(timeout()), this, SLOT(display_topbar()));

}

void MainWindow::init_screen1()
{
    plane = 1;
    slide_id=0;
    timer_10->start(33);

    /*TOP BAR*/
    update_datetime();

    /*CONTROL*/
    ui->button_A->setIcon(QIcon(":/resource/icons/icon_ds18.png"));
    ui->button_A->setIconSize(QSize(120, 120));
    ui->button_B->setIcon(QIcon(":/resource/icons/icon_ds2.png"));
    ui->button_B->setIconSize(QSize(150, 150));
    ui->button_C->setIcon(QIcon());
    ui->button_C->setStyleSheet("border: none; color: #FFFFFF; image: url(:/resource/icons/icon_ds30.png);");
    ui->button_C->setText(QString::number(val_zoom, 'f', 1) + "x");

    ui->button_A->show();
    ui->button_B->show();
    ui->button_C->show();

    ui->wifi_icon->setPixmap(QPixmap(":/resource/icons/icon_ds22.png"));

    ui->button_D->setIcon(QIcon(":/resource/icons/icon_ds22.png"));
    ui->button_E->setIcon(QIcon(":/resource/icons/icon_ds13.png"));
    ui->button_F->setIcon(QIcon(":/resource/icons/icon_ds10.png"));
    ui->button_G->setIcon(QIcon(":/resource/icons/icon_ds6.png"));
    ui->button_H->setIcon(QIcon(":/resource/icons/icon_ds20.png"));
    ui->button_I->setIcon(QIcon(":/resource/icons/icon_ds3.png"));
    ui->button_D->setIconSize(QSize(75, 75));
    ui->button_E->setIconSize(QSize(75, 75));
    ui->button_F->setIconSize(QSize(75, 75));
    ui->button_G->setIconSize(QSize(75, 75));
    ui->button_H->setIconSize(QSize(75, 75));
    ui->button_I->setIconSize(QSize(75, 75));

    ui->bg_opt->hide();
    ui->button_D->hide();
    ui->button_E->hide();
    ui->button_F->hide();
    ui->button_G->hide();
    ui->button_H->hide();
    ui->button_I->show();

    ui->scrollBar->hide();
}

void MainWindow::init_screen2()
{
    plane = 2;
    timer_10->stop();

    ui->button_A->setIcon(QIcon(":/resource/icons/icon_ds25.png"));
    ui->button_A->setIconSize(QSize(120, 120));
    ui->button_B->setIcon(QIcon(":/resource/icons/icon_ds16.png"));
    ui->button_B->setIconSize(QSize(150, 150));

    ui->button_C->setStyleSheet("border:none;");
    ui->button_C->setText("");

    ui->button_C->setIcon(QIcon(":/resource/icons/icon_ds26.png"));
    ui->button_C->setIconSize(QSize(120, 120));

    ui->bg_opt->setStyleSheet("background-color:rgba(0,0,0,150); color:#FFFFFF;");
    ui->bg_opt->show();
    ui->button_D->setIcon(QIcon(":/resource/icons/icon_ds8.png"));
    ui->button_D->show();
    ui->button_E->hide();
    ui->button_F->hide();
    ui->button_G->hide();
    ui->button_H->hide();
    ui->button_I->hide();

    ui->scrollBar->hide();
    ui->label_grid->hide();

    QString galleryPath = QDir::currentPath() + "/gallery/";
    QFileInfoList fileList = QDir(galleryPath).entryInfoList(QDir::Files, QDir::SortFlag::Name);
    val_galleryindex = fileList.size() - 1;

    update_screen2();
}

void MainWindow::init_screen3()
{
    plane = 3;
    ui->button_I->setIcon(QIcon(":/resource/icons/icon_ds28.png"));
    ui->bg_opt->setStyleSheet("background-color:#000000;");
    ui->bg_opt->show();
    ui->button_D->show();
    ui->button_E->show();
    ui->button_F->show();
    ui->button_G->show();
    ui->button_H->show();
    ui->button_I->show();
}

void MainWindow::update_screen1()
{
    if (plane == 1 || plane == 3)
    {
        cv::Mat frame, croppedImage, frame2;

        if (!capture->read(frame) || frame.empty()) {

            return;
        }

        frame.convertTo(frame, -1, val_contrast, val_brightness);

        cv::Rect2f zoomRect(
                    (frame.size().width / 2) * (1 - 1 / val_zoom),
                    (frame.size().height / 2) * (1 - 1 / val_zoom),
                    frame.size().width / val_zoom,
                    frame.size().height / val_zoom
                    );

        zoomRect = zoomRect & cv::Rect2f(0, 0, frame.size().width, frame.size().height);

        croppedImage = frame(zoomRect);


        double w_factor = static_cast<double>(1360) / croppedImage.size().width;
        double h_factor = static_cast<double>(1020) / croppedImage.size().height;

        cv::resize(croppedImage, frame, cv::Size(), w_factor, h_factor, cv::INTER_LINEAR);

        QImage qimg((const uchar*)frame.data, frame.cols, frame.rows, frame.step,QImage::Format_RGB888);
        QPixmap pixmap = QPixmap::fromImage(qimg.rgbSwapped());
        ui->cam_feed->setPixmap(pixmap.scaled(ui->cam_feed->size()));

        if (flag_capture)
        {
            store_image(frame);
        }
        else if (flag_wifi)
        {
            wifi_config(frame);
        }
    }
}

void MainWindow::update_screen2()
{
    QString galleryPath = "/opt/dermscopev310/bin/gallery/";
    QFileInfoList fileList = QDir(galleryPath).entryInfoList(QDir::Files, QDir::SortFlag::Name);

    if(fileList.size()!=0)
    {
        if (val_galleryindex < 0) {
            val_galleryindex = 0;
        } else if (val_galleryindex >= fileList.size()) {
            val_galleryindex = fileList.size() - 1;
        }

        QString filePath = fileList.at(val_galleryindex).absoluteFilePath();
        cv::Mat image = cv::imread(filePath.toStdString(), cv::IMREAD_COLOR);

        QImage qimg((uchar*)image.data, image.cols, image.rows, QImage::Format_RGB888);
        QPixmap pixmap = QPixmap::fromImage(qimg.rgbSwapped());  // Convert BGR to RGB

        ui->cam_feed->setPixmap(pixmap.scaled(ui->cam_feed->size(), Qt::KeepAspectRatio, Qt::FastTransformation));

        QString indexText = QString::number(val_galleryindex+1);
        QString sizeText = QString::number(fileList.size());
        ui->bg_opt->setText(indexText + " of " + sizeText);
    }
    else
    {   ui->bg_opt->setStyleSheet("color:#e5a50a");
        ui->bg_opt->setText("No image to display");
        ui->cam_feed->setPixmap(QPixmap());
    }
}

void MainWindow::update_datetime()
{
    QTime currentTime = QTime::currentTime();
    QString formattedTime = currentTime.toString("h:mm AP");
    ui->label_datetime->setText(formattedTime);
    system("sudo systemctl restart ntpd.service");
    system("sudo systemctl restart ntpdate.service");



    //    system("sudo systemctl enable ntpd.service");
    //    system("sudo systemctl restart ntpd.service");
    //    system("sudo systemctl restart ntpdate.service");
    //    system("sudo ntpdate 0.pk.pool.ntp.org");
    //    system("sudo systemctl disable ntpd.service");

}

void MainWindow::setTimeZone() {
    QProcess process;
    QStringList args;
    args << "-sf" << "/usr/share/zoneinfo/America/New_York" << "/etc/localtime";
    process.start("ln", args);
    process.waitForFinished();
    if (process.exitCode() != 0) {

    } else {

    }
}

void MainWindow::store_image(cv::Mat img)
{
    QString currentDateTime = QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss");
    QString baseName = "DERMSCOPE_IMG";
    QString fileName = QString("%1_%2.jpg").arg(baseName).arg(currentDateTime);

    std::string imagePath = ("/opt/dermscopev310/bin/gallery/" + fileName).toStdString();

    qDebug() << QString::fromStdString(imagePath);
    if (!cv::imwrite(imagePath, img)) {

        return;
    }

    sendImageToServer(fileName, img);


    flag_capture = false;
}

void MainWindow::delete_image()
{
    QString galleryPath =  "/opt/dermscopev310/bin/gallery/";
    QFileInfoList fileList = QDir(galleryPath).entryInfoList(QDir::Files, QDir::SortFlag::Name);

    if(fileList.size()!=0)
    {
        QString filePath = fileList.at(val_galleryindex).absoluteFilePath();
        QFile file(filePath);
        file.remove();
    }
    update_screen2();
}

void MainWindow::on_button_A_pressed()
{
    ui->button_A->setIconSize(QSize(108, 108));
}

void MainWindow::on_button_A_released()
{
    ui->button_A->setIconSize(QSize(120, 120));
    QString galleryPath = "/opt/dermscopev310/bin/gallery/";
    QFileInfoList fileList = QDir(galleryPath).entryInfoList(QDir::Files, QDir::SortFlag::Name);
    switch(plane)
    {
    case 1:
        init_screen2();
        break;
    case 2:
        if(fileList.size()!=0)
        {
            if(val_galleryindex == 0) val_galleryindex = fileList.size() - 1;
            else val_galleryindex = val_galleryindex - 1;
        }
        update_screen2();
        break;
    case 3:
        init_screen2();
        break;
    }



}

void MainWindow::on_button_B_pressed()
{
    ui->button_B->setIconSize(QSize(135,135));
}

void MainWindow::on_button_B_released()
{
    switch(plane)
    {
    case 1:

        flag_capture = true;
        ui->button_B->setIconSize(QSize(150, 150));
        break;
    case 2:
        delete_image();
        update_screen2();
        break;
    case 3:
        flag_capture = true;
        ui->button_B->setIconSize(QSize(150, 150));
        break;
    }
}

void MainWindow::on_button_C_pressed()
{
    ui->button_C->setIconSize(QSize(108, 108));
    ui->button_E->setIcon(QIcon(":/resource/icons/icon_ds13.png"));
    ui->button_F->setIcon(QIcon(":/resource/icons/icon_ds10.png"));
}

void MainWindow::on_button_C_released()
{
    ui->button_C->setIconSize(QSize(120,120));
    QString galleryPath = "/opt/dermscopev310/bin/gallery/";
    QFileInfoList fileList = QDir(galleryPath).entryInfoList(QDir::Files, QDir::SortFlag::Name);
    switch(plane)
    {
    case 1:
        slide_id = 0;
        if(zoom_toggle)
        {
            ui->scrollBar->hide();
            ui->button_C->setStyleSheet("border: none; color: #FFFFFF; image: url(:/resource/icons/icon_ds30.png);");
            zoom_toggle=false;
        }
        else
        {
            ui->scrollBar->setMinimum(10);
            ui->scrollBar->setMaximum(20);
            ui->scrollBar->setSingleStep(1);
            ui->scrollBar->setPageStep(5);
            ui->scrollBar->setValue(int(val_zoom*10));
            ui->scrollBar->show();
            ui->button_C->setStyleSheet("border: none; color: #E5A50A; image: url(:/resource/icons/icon_ds30.png);");
            zoom_toggle=true;
        }

        break;

    case 2:
        if(fileList.size()!=0)
        {
            val_galleryindex = val_galleryindex + 1;
            val_galleryindex = val_galleryindex % fileList.size();
        }
        update_screen2();
        break;
    case 3:
        slide_id = 0;
        if(zoom_toggle2)
        {
            ui->scrollBar->hide();
            zoom_toggle2=false;
        }
        else
        {
            ui->scrollBar->setMinimum(10);
            ui->scrollBar->setMaximum(20);
            ui->scrollBar->setSingleStep(1);
            ui->scrollBar->setPageStep(5);
            ui->scrollBar->setValue(int(val_zoom*10));
            ui->scrollBar->show();
            ui->button_C->setStyleSheet("color:#e5a50a");
            zoom_toggle2=true;
        }
        break;
    }
}

void MainWindow::on_button_I_pressed()
{
    ui->button_I->setIconSize(QSize(65, 65));
}

void MainWindow::on_button_I_released()
{
    switch(plane)
    {
    case 1:
        ui->button_I->setIconSize(QSize(75, 75));
        ui->scrollBar->hide();
        init_screen3();

        break;
    case 3:
        ui->button_I->setIconSize(QSize(75, 75));
        ui->scrollBar->hide();
        init_screen1();
        break;
    }

}

void MainWindow::on_button_D_pressed()
{
    ui->button_D->setIconSize(QSize(65, 65));
}

void MainWindow::on_button_D_released()
{
    switch(plane)
    {
    case 2:
        ui->button_D->setIconSize(QSize(75, 75));
        init_screen1();
        break;
    case 3:
        ui->button_D->setIconSize(QSize(75, 75));
        flag_wifi=true;
        break;
    }

}

void MainWindow::on_button_E_pressed()
{
    ui->button_E->setIconSize(QSize(65, 65));
    ui->button_F->setIcon(QIcon(":/resource/icons/icon_ds10.png"));
}

void MainWindow::on_button_E_released()
{
    slide_id = 1;

    if (contrast_toggle)
    {
        ui->button_E->setIcon(QIcon(":/resource/icons/icon_ds13.png"));
        contrast_toggle = false;
        ui->scrollBar->hide();
    }
    else
    {
        ui->button_E->setIcon(QIcon(":/resource/icons/icon_ds14.png"));
        ui->scrollBar->setMinimum(0);
        ui->scrollBar->setMaximum(30);
        ui->scrollBar->setPageStep(15);
        ui->scrollBar->setSingleStep(1);
        ui->scrollBar->setValue(int((val_contrast + 0.5) * 10));
        ui->scrollBar->show();
        contrast_toggle = true;
        brightness_toggle = false;
    }
    ui->button_E->setIconSize(QSize(75, 75));

}

void MainWindow::on_button_F_pressed()
{
    ui->button_F->setIconSize(QSize(65, 65));
    ui->button_E->setIcon(QIcon(":/resource/icons/icon_ds13.png"));
}

void MainWindow::on_button_F_released()
{
    slide_id = 2;
    if (brightness_toggle)
    {
        ui->button_F->setIcon(QIcon(":/resource/icons/icon_ds10.png"));
        brightness_toggle = false;
        ui->scrollBar->hide();
    }
    else
    {
        ui->scrollBar->setMinimum(0);
        ui->scrollBar->setMaximum(140);
        ui->scrollBar->setPageStep(70);
        ui->scrollBar->setSingleStep(1);
        ui->scrollBar->setValue(val_brightness+70);
        ui->button_F->setIcon(QIcon(":/resource/icons/icon_ds11.png"));
        ui->button_F->setIconSize(QSize(75, 75));
        ui->scrollBar->show();
        brightness_toggle = true;
        contrast_toggle = false;
    }
    ui->button_F->setIconSize(QSize(75, 75));
}

void MainWindow::on_button_G_pressed()
{
    ui->button_G->setIconSize(QSize(65, 65));

}

void MainWindow::on_button_G_released()
{
    if (gridtoggle)
    {
        ui->button_G->setIcon(QIcon(":/resource/icons/icon_ds6.png"));
        ui->label_grid->clear();
        gridtoggle = false;
    }
    else
    {
        ui->label_grid->raise();
        ui->label_grid->show();
        init_screen3();
        ui->scrollBar->raise();
        ui->button_G->setIcon(QIcon(":/resource/icons/icon_ds5.png"));
        QPixmap pixmap(":/resource/icons/grid_img.png");
        ui->label_grid->setPixmap(pixmap.scaled(ui->label_grid->size(), Qt::KeepAspectRatio, Qt::FastTransformation));
        gridtoggle = true;
    }
    ui->button_G->setIconSize(QSize(75, 75));

}

void MainWindow::on_button_H_pressed()
{
    ui->button_H->setIconSize(QSize(67, 67));
}

void MainWindow::on_button_H_released()
{
    ui->button_H->setIconSize(QSize(75, 75));
    polarization_toggle = (polarization_toggle + 1) % 3;

    QPropertyAnimation *animation = new QPropertyAnimation(ui->icon_prompt, "geometry");
    animation->setDuration(100);
    QRect startRect = QRect(120, 0, ui->icon_prompt->width(), ui->icon_prompt->height());
    QRect endRect = QRect(120, 80, ui->icon_prompt->width(), ui->icon_prompt->height());
    animation->setStartValue(startRect);
    animation->setEndValue(endRect);
    QFont font("Product Sans", 22, QFont::Bold);
    ui->icon_prompt->setFont(font);
    ui->icon_prompt->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);



    switch (polarization_toggle) {
    case 0:
        system("echo 0 > /sys/class/gpio/gpio124/value");
        timer_pol->start(2000);
        ui->button_H->setIcon(QIcon(":/resource/icons/icon_ds20.png"));
        ui->button_H->setEnabled(false);
        ui->icon_prompt->show();
        ui->icon_prompt->setText("\tNo\n\tPolarization");
        connect(animation, &QPropertyAnimation::finished, animation, &QPropertyAnimation::deleteLater);
        animation->start();
        timer_topbar->start(2000);
        break;
    case 1:
        ui->button_H->setIcon(QIcon(":/resource/icons/icon_ds15.png"));
        system("echo 0 > /sys/class/gpio/gpio124/value");
        ui->button_H->setEnabled(false);
        timer_pol->start(10);
        ui->icon_prompt->show();
        ui->icon_prompt->setText("\tCross\n\tPolarization");
        connect(animation, &QPropertyAnimation::finished, animation, &QPropertyAnimation::deleteLater);
        animation->start();
        timer_topbar->start(2000);
        break;
    case 2:
        ui->button_H->setIcon(QIcon(":/resource/icons/icon_ds29.png"));
        system("echo 0 > /sys/class/gpio/gpio124/value");
        ui->button_H->setEnabled(false);
        timer_pol->start(10);
        ui->icon_prompt->show();
        ui->icon_prompt->setText("\tLinear\n\tPolarization");
        connect(animation, &QPropertyAnimation::finished, animation, &QPropertyAnimation::deleteLater);
        animation->start();
        timer_topbar->start(2000);
        break;
    }
}

void MainWindow::close_polarization()
{
    system("echo 1 > /sys/class/gpio/gpio124/value");
    timer_pol->stop();
    ui->button_H->setEnabled(true);
}

MainWindow::~MainWindow()
{
    delete ui;

}

void MainWindow::on_scrollBar_sliderMoved(int position)
{
    switch (slide_id) {
    case 0:
        val_zoom = position/10.0;
        ui->button_C->setText(QString::number(val_zoom, 'f', 1) + "x");
        break;

    case 1:
        val_contrast = (position/10.0)-0.5;
        break;

    case 2:
        val_brightness = position - 70;
        break;
    }
}

void MainWindow::wifi_config(cv::Mat qr_frame)
{
    std::string token, ssid, password;
    std::string essidInfo = "";

    Mat gray_img = qr_frame;
    cvtColor(qr_frame, gray_img, COLOR_BGR2GRAY);
    QString qrCodeData;
    QRCodeDetector qrDet;
    std::string qrCodeDataStdString = qrDet.detectAndDecode(gray_img);
    qrCodeData = QString::fromStdString(qrCodeDataStdString);


    if (qrCodeData.isEmpty()) {
        ui->icon_prompt->show();
        QPropertyAnimation *animation = new QPropertyAnimation(ui->icon_prompt, "geometry");
        animation->setDuration(100);
        QRect startRect = QRect(120, 0, ui->icon_prompt->width(), ui->icon_prompt->height());
        QRect endRect = QRect(120, 80, ui->icon_prompt->width(), ui->icon_prompt->height());
        animation->setStartValue(startRect);
        animation->setEndValue(endRect);
        QFont font("Product Sans", 22, QFont::Bold);
        ui->icon_prompt->setFont(font);
        ui->icon_prompt->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        ui->icon_prompt->setText("\tNo QR Code Detected");
        animation->start();
        timer_topbar->start(2000);
    }
    else
    {
        std::istringstream ss(qrCodeDataStdString);

        std::string qrCodeDataStdString = qrCodeData.toStdString();

        while (getline(ss, token, ';')) {
            if (token.find("S:") != std::string::npos)
            {
                ssid = token.substr(token.find("S:") + 2);
            }
            else if (token.find("P:") != std::string::npos)
            {
                password = token.substr(token.find("P:") + 2);
            }
        }

        std::ofstream configFile("/etc/wpa_supplicant.conf");
        if (configFile.is_open()) {
            configFile << "network={\n";
            configFile << "    ssid=\"" << ssid << "\"\n";
            configFile << "    psk=\"" << password << "\"\n";
            configFile << "}\n";
            configFile.close();
        }

        FILE* pipe = popen("iwgetid", "r");
        if (!pipe) {
            std::cerr << "Error: Failed to execute iwconfig command" << std::endl;
        }
        char buffer[256];
        while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
            if (strstr(buffer, "ESSID") != NULL) {
                char* essidStart = strstr(buffer, "ESSID:\"") + strlen("ESSID:\"");
                char* essidEnd = strchr(essidStart, '\"');
                *essidEnd = '\0';
                essidInfo = essidStart;
                break;
            }
        }
        pclose(pipe);
        std::cout << "ESSID: " << essidInfo << std::endl;

        if (essidInfo == ssid) {
            ui->icon_prompt->show();
            QPropertyAnimation *animation = new QPropertyAnimation(ui->icon_prompt, "geometry");
            animation->setDuration(100);
            QRect startRect = QRect(120, 0, ui->icon_prompt->width(), ui->icon_prompt->height());
            QRect endRect = QRect(120, 80, ui->icon_prompt->width(), ui->icon_prompt->height());
            animation->setStartValue(startRect);
            animation->setEndValue(endRect);
            QFont font("Product Sans", 22, QFont::Bold);
            ui->icon_prompt->setFont(font);
            ui->icon_prompt->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            ui->icon_prompt->setText("\tNetwork Connection\n\tSUCCESSFUL");
            animation->start();
            timer_topbar->start(15000);
            ui->wifi_icon->show();
        } else {
            ui->icon_prompt->show();
            QPropertyAnimation *animation = new QPropertyAnimation(ui->icon_prompt, "geometry");
            animation->setDuration(100);
            QRect startRect = QRect(120, 0, ui->icon_prompt->width(), ui->icon_prompt->height());
            QRect endRect = QRect(120, 80, ui->icon_prompt->width(), ui->icon_prompt->height());
            animation->setStartValue(startRect);
            animation->setEndValue(endRect);
            QFont font("Product Sans", 22, QFont::Bold);
            ui->icon_prompt->setFont(font);
            ui->icon_prompt->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            ui->icon_prompt->setText("\tNetwork Connection\n\tFAILED");
            animation->start();
            timer_topbar->start(15000);
            ui->wifi_icon->hide();

        }
        int status = system("sudo systemctl restart inventron-init.service");
        if (status == 0) {
            ui->wifi_icon->show();
        } else {
            ui->wifi_icon->hide();
        }
    }   flag_wifi=false;
}

void MainWindow::checkConnection()
{
    std::ifstream configFile("/etc/wpa_supplicant.conf");
    std::string line, ssid, essidInfo;
    // Read each line from the file
    while (std::getline(configFile, line)) {
        // Check if the line contains the SSID
        size_t pos = line.find("ssid=\"");
        if (pos != std::string::npos) {
            // Extract the SSID
            ssid = line.substr(pos + 6); // 6 is the length of "ssid=\""
            ssid = ssid.substr(0, ssid.find('"')); // Extracting the SSID until the next double quote
            break; // Stop reading further after finding the SSID
        }
    }

    // Close the file
    configFile.close();

    // Checking ESSID
    FILE* pipe = popen("iwgetid", "r");
    if (!pipe) {
        std::cerr << "Error: Failed to execute iwconfig command" << std::endl;
        return; // Exit if popen failed
    }

    // Buffer to store each line of output
    char buffer[256];
    // Read output line by line
    while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
        // Check if the line contains ESSID information
        if (strstr(buffer, "ESSID") != NULL) {
            // Extract ESSID information
            char* essidStart = strstr(buffer, "ESSID:\"") + strlen("ESSID:\"");
            char* essidEnd = strchr(essidStart, '\"');
            if (essidEnd) {
                *essidEnd = '\0'; // Null-terminate the string
                essidInfo = essidStart;
            }
            break; // Exit loop after finding ESSID
        }
    }
    pclose(pipe);
    std::cout << "ESSID: " << essidInfo << std::endl;

    if (essidInfo == ssid)
    {
        ui->wifi_icon->show();
    }
    else
    {
        ui->wifi_icon->hide();
    }

}

void MainWindow::updateNtpConf() {
    QFile ntpConfFile("/etc/ntp.conf");
    if (!ntpConfFile.open(QIODevice::ReadOnly | QIODevice::Text)) {

        return;
    }

    QTextStream in(&ntpConfFile);
    QStringList ntpConfigLines;
    bool driftfileExist = false;
    bool loggingExist = false;
    bool defaultRestrictionsExist = false;
    QSet<QString> existingServers;

    // Read existing configurations
    while (!in.atEnd()) {
        QString line = in.readLine();
        QString trimmedLine = line.trimmed();
        if (trimmedLine.startsWith("server") && !trimmedLine.contains("127.127.1.0")) {
            existingServers.insert(trimmedLine);
        } else if (trimmedLine.startsWith("driftfile")) {
            driftfileExist = true;
        } else if (trimmedLine.startsWith("logfile")) {
            loggingExist = true;
        } else if (trimmedLine.startsWith("restrict")) {
            defaultRestrictionsExist = true;
        }
        ntpConfigLines << line;
    }
    ntpConfFile.close();

    // List of required server lines
    QStringList requiredServers = {
        "server 0.pk.pool.ntp.org iburst",
        "server 1.pk.pool.ntp.org iburst",
        "server 2.pk.pool.ntp.org iburst",
        "server 3.pk.pool.ntp.org iburst"
    };

    // Add missing server lines
    for (const QString &server : requiredServers) {
        if (!existingServers.contains(server)) {

            ntpConfigLines << server;
        }
    }

    // Add missing configurations
    if (!driftfileExist) {

        ntpConfigLines << "\n# Specify the drift file location";
        ntpConfigLines << "driftfile /var/lib/ntp/drift";
    }
    if (!loggingExist) {

        ntpConfigLines << "\n# Logging";
        ntpConfigLines << "logfile /var/log/ntp.log";
    }
    if (!defaultRestrictionsExist) {

        ntpConfigLines << "\n# Default restrictions";
        ntpConfigLines << "# Allow localhost to query the NTP server";
        ntpConfigLines << "restrict 127.0.0.1";
        ntpConfigLines << "restrict ::1";
    }

    // Write the updated configuration lines back to the file
    QFile ntpConfFileWrite("/etc/ntp.conf");
    if (!ntpConfFileWrite.open(QIODevice::WriteOnly | QIODevice::Text)) {

        return;
    }

    QTextStream out(&ntpConfFileWrite);
    for (const QString& line : ntpConfigLines) {
        out << line << "\n"; // Add newline character
    }
    ntpConfFileWrite.close();

}

void MainWindow::set_sleep()
{
    timer_10->stop();
    system("echo powersave > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor");
}

void MainWindow::wake_up()
{  
    timer_10->start(10);
    system("echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor");
}

void MainWindow::sleepbygpio()
{
    QFile file("/sys/class/gpio/gpio89/value");
    if (file.open(QIODevice::ReadOnly))
    {
        QTextStream in(&file);
        QString value = in.readLine().trimmed();
        file.close();


        if (value == "0")
        {
            switch (inSleepMode)
            {
            case 0:
                inSleepMode=true;
                set_sleep();
                break;
            case 1:
                inSleepMode=false;
                wake_up();
                break;
            }
        }
    }
}

void MainWindow::captureImagebygpio()
{
    if (timer_10->isActive())
    {
        QFile file("/sys/class/gpio/gpio96/value");

        QTextStream in(&file);
        QString value = in.readLine().trimmed();
        file.close();



        if (value == "0")
        {
            flag_capture = true;
        }
    }
}

void MainWindow::polarizebygpio()
{
    QFile file("/sys/class/gpio/gpio83/value");
    if (file.open(QIODevice::ReadOnly))
    {
        QTextStream in(&file);
        QString value = in.readLine().trimmed();
        file.close();



        if (value == "0")
        {
            on_button_H_released();
        }
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
//    standbyTimer->start();
//    if (standbymode) {
//        timer_10->start(10);
//        standbymode = false;
//    }
    // Check if the zoom bar is visible and the mouse press event occurs outside the zoom bar
    if (ui->scrollBar->isVisible() && !ui->scrollBar->geometry().contains(event->pos())) {
        ui->scrollBar->setVisible(false);
        ui->button_C->setStyleSheet("border: none; color: #FFFFFF; image: url(:/resource/icons/icon_ds30.png);");
    }



    if (gridtoggle) {
        // Get the positions of button_B and button_C relative to the main window
        QRect buttonBRect = ui->button_B->geometry();
        QRect buttonCRect = ui->button_C->geometry();

        // Convert button B and C positions to main window coordinates
        buttonBRect.moveTopLeft(ui->button_B->mapToGlobal(QPoint(0, 0)));
        buttonCRect.moveTopLeft(ui->button_C->mapToGlobal(QPoint(0, 0)));

        // Check if the click is outside button_B and button_C
        if (!buttonBRect.contains(event->globalPos()) && !buttonCRect.contains(event->globalPos())) {
            // Hide grid label if it is visible
            if (gridtoggle) {
                ui->label_grid->clear();
                ui->button_G->setIcon(QIcon(":/resource/icons/icon_ds6.png"));
                gridtoggle = false;
                zoom_toggle2 = false;

            }
        }
    }
    // If not in sleep mode, handle the click as usual
    QMainWindow::mousePressEvent(event);
}


void MainWindow::sendImageToServer(const QString &fileName, const cv::Mat &frame)
{

    QPropertyAnimation *animation = new QPropertyAnimation(ui->icon_prompt, "geometry");
    animation->setDuration(100);
    QRect startRect = QRect(120, 0, ui->icon_prompt->width(), ui->icon_prompt->height());
    QRect endRect = QRect(120, 80, ui->icon_prompt->width(), ui->icon_prompt->height());
    animation->setStartValue(startRect);
    animation->setEndValue(endRect);
    QFont font("Product Sans", 22, QFont::Bold);
    ui->icon_prompt->setFont(font);
    ui->icon_prompt->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    // Convert OpenCV Mat to QImage
    QImage qImage((uchar*)frame.data, frame.cols, frame.rows, QImage::Format_BGR888); // Assuming image format is BGR

    // Convert QImage to QByteArray for server upload (if needed)
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    qImage.save(&buffer, "JPG");

    // Convert QByteArray to Base64
    QString imgData = byteArray.toBase64();

    // Prepare JSON data to send
    QJsonObject json;
    json["fileName"] = fileName;
    json["imgData"] = imgData;
    json["deviceID"] = "Dev1"; // Replace with actual device ID
    json["end"] = "true"; // Assuming you want to upload to Drive

    if (imgData.isEmpty()) {

        return;
    } else {

    }


    // Prepare request to server
    QUrl url("http://13.127.69.50/savefile");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    // Send data to server using QNetworkAccessManager
    QNetworkAccessManager *manager = new QNetworkAccessManager(this);
    QNetworkReply *reply = manager->post(request, QJsonDocument(json).toJson());



    // Handle server response asynchronously
    connect(reply, &QNetworkReply::finished, [=]() {
        if (reply->error() == QNetworkReply::NoError) {
            QByteArray responseData = reply->readAll();

            // Parse the server response
            QJsonDocument jsonResponse = QJsonDocument::fromJson(responseData);
            QJsonObject jsonObject = jsonResponse.object();

            // Check for success message in the response
            if (jsonObject.contains("message") && jsonObject["message"].toString() == "Image Created Sucessfully and Saved to Drive")

            {
                ui->icon_prompt->setText("\tImage Saved to Server");
                animation->start();
                timer_topbar->start(4000);
            }
        } else {
            ui->icon_prompt->setText("\tImage did not sent");
            animation->start();
            timer_topbar->start(4000);
        }
        reply->deleteLater();
        manager->deleteLater();
    });
}

void MainWindow::display_topbar() {
    ui->icon_prompt->setText("");
    ui->icon_prompt->hide();
}


//////////////////////////////////////////////////////////////////////
/// i2c library for reading data
//////////////////////////////////////////////////////////////////////
void MainWindow::openI2C()
{
    i2cFile = open("/dev/i2c-2", O_RDWR);
    if (i2cFile < 0) {
        qWarning() << "Failed to open I2C bus";
        return;
    }


    if (ioctl(i2cFile, I2C_SLAVE,max17043_address) < 0) {
        qWarning() << "Failed to acquire bus access and/or talk to slave";
        closeI2C(); // Close the file descriptor if setting the slave address fails
        return;
    }

}

void MainWindow::closeI2C()
{
    if (i2cFile >= 0) {
        //        close(i2cFile);
        i2cFile = -1;
    }
}

int MainWindow::readI2CInteger(uint8_t reg)
{
    if (i2cFile < 0) {
        qWarning() << "I2C file not open";
        return -1;
    }

    uint8_t buf[2];
    buf[0] = reg;
    if (write(i2cFile, buf, 1) != 1) {
        qWarning() << "Failed to write register address to the I2C bus. Error:" << strerror(errno);
        return -1;
    }

    if (read(i2cFile, buf, 2) != 2) {
        qWarning() << "Failed to read from the I2C bus. Error:" << strerror(errno);
        return -1;
    }

    int data = (buf[0] << 8) | buf[1];
    return data;
}

void MainWindow::writeI2CRegister(uint8_t reg, uint16_t value)
{
    if (i2cFile < 0) {
        qWarning() << "I2C file not open";
        return;
    }

    uint8_t buf[3];
    buf[0] = reg;
    buf[1] = value >> 8;
    buf[2] = value & 0xFF;
    if (write(i2cFile, buf, 3) != 3) {
        qWarning() << "Failed to write to the I2C bus. Error:" << strerror(errno);
        return;
    }
}

float MainWindow::readVoltage()
{
    int vcell = readI2CInteger(MAX17043_VCELL);
    if (vcell < 0)
        return -1.0f;

    return 1.25f * static_cast<float>(vcell >> 4);
}

float MainWindow::readPercentage()
{
    int soc = readI2CInteger(MAX17043_SOC);
    if (soc < 0)
        return -1.0f;

    return (soc >> 8) + 0.003906f * (soc & 0xFF);
}

int MainWindow::initializeMAX17043()
{
    // Power on reset
    writeI2CRegister(MAX17043_COMMAND, 0x5400);
    QThread::msleep(10); // Adjust delay as per your device's requirements

    // Verify configuration

    if (readI2CInteger(MAX17043_CONFIG) == 0x971c) {
        // Configure for quick start
        writeI2CRegister(MAX17043_MODE, 0x4000);
        writeI2CRegister(MAX17043_CONFIG, 0x9700);

        QThread::msleep(10); // Adjust delay as per your device's requirements
        return 0;
    }
    return -1;
}


void MainWindow::updateBatteryInfo()
{
    int time=0;
    float voltage = readVoltage();
    voltage = voltage/1000;
    float percentage = 166*voltage-533;
    if(percentage < 1) percentage = 0;
    else if (percentage > 100) percentage = 100;

    ui->batteryBar->setValue(percentage);

    qDebug() << "Voltage: " << voltage;
    qDebug() << "Percentage: " << percentage;
    switch(ctr)
    {
    case 0:
        //Initial Condition
        ctr = 1;
        prev = voltage;
        break;
    case 1:
    case 2:
    case 3:
        //Normal Condition
        if(percentage <= 20)
        {
            ui->icon_battery->show();
            ui->label_battery->setText("LOW");
            ui->label_battery->setStyleSheet("color:#FF0000;");
            ui->batteryBar->setStyleSheet(
                        "QProgressBar { border: none; background-color: #000000; } "
                        "QProgressBar::chunk { background-color: #FF0000; }");
        }
        else if (percentage > 20 && percentage <= 50)
        {
            ui->icon_battery->show();
            ui->label_battery->setText(QString::number(static_cast<int>(percentage)) + "%");
            ui->label_battery->setStyleSheet("color:#FFFFFF;");
            ui->batteryBar->setStyleSheet(
                        "QProgressBar { border: none; background-color: #000000; } "
                        "QProgressBar::chunk { background-color: #E88504; }");
        }
        else
        {
            ui->icon_battery->show();
            ui->label_battery->setText(QString::number(static_cast<int>(percentage)) + "%");
            ui->label_battery->setStyleSheet("color:#FFFFFF;");
            ui->batteryBar->setStyleSheet(
                        "QProgressBar { border: none; background-color: #000000; } "
                        "QProgressBar::chunk { background-color: #FFFFFF; }");
        }
        if(voltage > prev) ctr++;
        else ctr = 1;

        if(ctr == 4) ctr=7;
        prev = voltage;
        break;

    case 5:
    case 6:
    case 7:
        //Charging Condition
        if(voltage >= 4.1)
        {
            ui->label_battery->setText("100%");
            ui->label_battery->setStyleSheet("color:#00FF00;");
            ui->batteryBar->setValue(100);
            ui->batteryBar->setStyleSheet(
                        "QProgressBar { border: none; background-color: #000000; } "
                        "QProgressBar::chunk { background-color: #00FF00; }");
            ui->icon_battery->show();
        }
        else
        {
            ui->label_battery->setText("CHG");
            ui->label_battery->setStyleSheet("color:#00FF00;");
            ui->batteryBar->setValue(100);
            ui->batteryBar->setStyleSheet(
                        "QProgressBar { border: none; background-color: #000000; } "
                        "QProgressBar::chunk { background-color: #000000; }");
            ui->icon_battery->hide();

            if(voltage < prev) ctr--;
            else ctr = 7;

            if(ctr==4) ctr=1;
            prev = voltage;
        }
        break;
    }





        //    float voltage = readVoltage();
        //    float percentageValue;

        //    const float fluctuationThreshold = 100.0;  // Fluctuation threshold set to 100 mV

        //    if (i == 0)
        //    {
        //        prev = voltage;
        //        difference = 0;
        //        i++;
        //        AV = voltage;
        //    }
        //    else
        //    {
        //        difference = voltage - prev;


        //        if (voltage > prev)  // Spike detected
        //        {
        //            flag = 1;
        //            temp = prev;

        //            // Set battery bar to custom green color on spike detection
        //            ui->batteryBar->setStyleSheet(
        //                        "QProgressBar { border: none; background-color: #00FF00; } "
        //                        "QProgressBar::chunk { background-color: rgb(51, 209, 122); }"); // Custom green color

        //            // Display "CHG" on spike
        //            ui->label_battery->setStyleSheet("background-color: rgb(0, 255, 0);  margin-left:40; margin-right:40; margin-top:15; margin-bottom:15; border-radius:10;");
        //            ui->label_battery->setText("");
        //            return;  // Skip the rest of the function until the spike disappears
        //        }
        //        else if (voltage <= prev)  // Decrease detected
        //        {
        //            flag = 0;
        //            ui->batteryBar->setStyleSheet(
        //                        "QProgressBar { border: none; background-color: #000000; } "
        //                        "QProgressBar::chunk { background-color: #FFFFFF; }"); // Default color

        //            // Show percentage when no spike is detected
        //            percentageValue = mapValue(AV, 3000.0, 4000.0, 0, 100);
        //            if (percentageValue > 100) percentageValue = 100;
        //            else if (percentageValue < 0) percentageValue = 0;


        //            ui->label_battery->setStyleSheet("background-color:#000000; color:#FFFFFF;");
        //            ui->label_battery->setText(QString::number(static_cast<int>(percentageValue)) + "%");
        //            ui->batteryBar->setValue(percentageValue);
        //        }

        //    }

        //    prev = voltage;

        //    // Use map function to calculate percentage based on voltage
        //    percentageValue = mapValue(AV, 3000.0, 4000.0, 0, 100);

        //    if (percentageValue > 100) percentageValue = 100;
        //    else if (percentageValue < 0) percentageValue = 0;

        //    // Display "Low" if the voltage is low and percentage is zero
        //    if (AV <= 3300 )
        //    {
        //        ui->label_battery->setText("Low");
        //        ui->label_battery->setStyleSheet("color:#FF0000;");
        //    }
        //    else if (flag == 0)  // Show percentage when no spike is detected
        //    {

        //        ui->label_battery->setText(QString::number(static_cast<int>(percentageValue)) + "%");
        //        ui->batteryBar->setValue(percentageValue);
        //    }
}





