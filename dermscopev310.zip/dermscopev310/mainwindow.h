#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "ui_mainwindow.h"
#include <QImage>
#include <QPixmap>
#include <QCoreApplication>
#include <QApplication>
#include <QTimer>
#include <QDebug>
#include <QFileSystemWatcher>
#include <QPropertyAnimation>
#include <opencv2/opencv.hpp>
#include <opencv2/objdetect.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void sendImageToServer(const QString &fileName, const cv::Mat &img);



private slots:
    void update_screen1();
    void on_button_B_pressed();
    void on_button_B_released();
    void on_button_A_pressed();
    void on_button_A_released();
    void on_button_C_pressed();
    void on_button_C_released();
    void on_button_I_pressed();
    void on_button_I_released();
    void on_button_D_pressed();
    void on_button_D_released();
    void on_button_E_pressed();
    void on_button_E_released();
    void on_button_F_pressed();
    void on_button_F_released();
    void on_button_G_pressed();
    void on_button_G_released();
    void on_button_H_pressed();
    void on_button_H_released();
    void on_scrollBar_sliderMoved(int position);
    void updateBatteryInfo();
    void checkConnection();
    void display_topbar();
    void setTimeZone();


private:
    Ui::MainWindow *ui;

    cv::VideoCapture *capture;
    int i2cFile;
    QTimer *timer_10;
    QTimer *timer_60000;
    QTimer *checkTimer;
    QTimer *timeri2c;
    QTimer *timer_pol;
    QTimer *timer_topbar;
    QTimer *standbyTimer;

    void init_sys();
    void init_timers();
    void init_screen1();
    void init_screen2();
    void init_camera();
    void init_screen3();
    void update_datetime();
    void store_image(cv::Mat);
    void update_screen2();
    void delete_image();
    void wifi_config(cv::Mat);
    void updateNtpConf();
    void setupGPIO();
    void sleepbygpio();
    void set_sleep();
    void wake_up();
    void captureImagebygpio();
    void polarizebygpio();
    void config_polarization();
    void close_polarization();

    bool flag_capture;
    bool flag_wifi;
    int plane;
    int slide_id;

    int val_galleryindex;
    double val_zoom;
    double val_contrast;
    double val_brightness;

    bool contrast_toggle;
    bool brightness_toggle;
    int polarization_toggle;
    bool gridtoggle;
    bool inSleepMode;
    bool zoom_toggle;
    bool zoom_toggle2;
    bool standbymode;

    const char *i2cDevice = "/dev/i2c-2";
    uint8_t max17043_address = 0x36; // MAX17043 I2C address
    void openI2C();
    void closeI2C();
    int readI2CInteger(uint8_t reg);
    void writeI2CRegister(uint8_t reg, uint16_t value);
    float readVoltage();
    float readPercentage();
    int initializeMAX17043();
    void gpio_watcher();
    void pol_done();
    QFileSystemWatcher watcher_sleep;
    QFileSystemWatcher  watcher_capture;
    QFileSystemWatcher  watcher_polarize;

    float prevVoltage = 0;
    float AV = 0;
    int flag = 0;
    bool firstUpdate = true;

protected:
    void mousePressEvent(QMouseEvent *event) override;

};
#endif // MAINWINDOW_H
